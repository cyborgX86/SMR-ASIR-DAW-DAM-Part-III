package joc.arena.interficie;

import java.util.Scanner;
import joc.arena.regles.Bestiari;
import joc.arena.regles.Combat;

public class EntradaTeclat {

  /** Tria l'adversari del jugador en base a la seva resposta.
   *
   * @return Cadena de text amb la resposta
   */
  public int[] triarAdversari(int nivell) {
    System.out.print("Contra quin adversari vols lluitar en aquest combat? ");
    Scanner lector = new Scanner(System.in);
    String resposta = lector.nextLine();
    Bestiari bestiari = new Bestiari();
    int[] adversari = bestiari.cercarAdversari(resposta);
    if (adversari == null) {
      System.out.println("Aquest enemic no existeix. Es tria a l'aztar.");
      adversari = bestiari.triarAdversariAtzar(nivell);
    }
    return adversari;
  }



  /** Pregunta a l'usuari quina estrategia vol usar, d'entre
   * les quatre possibles
   *
   * @return Accio a dur a terme, d'acord a les constants de la classe Combat, 
   */
  public int preguntarEstrategia() {
    Scanner lector = new Scanner(System.in);
    System.out.println("Quina estrategia vols seguir aquesta ronda?");
    System.out.println("[A]tacar\t[D]efensar\t[E]ngany\t[M]aniobra");
    System.out.println("--------");
    boolean preguntar = true;
    int accio = -1;
    while (preguntar) {
      System.out.print("Accio: ");
      String resposta = lector.nextLine();
      if ("A".equalsIgnoreCase(resposta)) {
        accio =  Combat.ATAC;
        preguntar = false;
      } else if ("D".equalsIgnoreCase(resposta)) {
        accio = Combat.DEFENSA;
        preguntar = false;
      } else if ("E".equalsIgnoreCase(resposta)) {
        accio = Combat.ENGANY;
        preguntar = false;
      } else if ("M".equalsIgnoreCase(resposta)) {
        accio = Combat.MANIOBRA;
        preguntar = false;
      } else {
        System.out.print("Accio incorrecta...");
      }
    }
    return accio;
  }

}
