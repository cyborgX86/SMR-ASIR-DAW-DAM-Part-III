package joc.arena.fitxers;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.Random;
import joc.arena.regles.Lluitador;

public class Bestiari {

  //Constant amb el nom del fitxer d'adversaris
  private static final File ADVERSARIS = new File("Adversaris");

  //Jugador: ID = 0
  private int[] jugador = {0,  1,  0, 10, 10, 3, 3, 3, 3};

  private Lluitador lluitador = new Lluitador();

  //Tots els metodes mantenen la seva declaracio (nom i parametres)

  /** Genera un nou jugador
   *
   * @return Un array amb les dades d'un jugador inicial
   */
  public int[] generarJugador() {
    lluitador.renovar(jugador);
    return jugador;
  }

  /** Donat un nom, genera l'aversari corresponent. Si aquest nom no existeix,
   * es genera a l'atzar.
   *
   * @param nomAdv Nom de l'adversari a obtenir
   * @return El Lluitador amb aquest nom, o null si no existeix
   */
  public int[] cercarAdversari(String nomAdv) {
    try {
      int[] adversari = null;    
      RandomAccessFile raf = new RandomAccessFile(ADVERSARIS, "r");
      long numAdv = ADVERSARIS.length()/50;
      for (int i = 0; i < numAdv; i++) {
        raf.seek(50*i);  
        String nom = llegirNom(raf);
        if (nom.equalsIgnoreCase(nomAdv)) {
          adversari = crearAdversari(raf,i);    
        }        
      }      
      raf.close();
      return adversari;
    } catch (Exception e) {
      return null;    
    }
  }

  /** Obte l'adversari que hi ha a en un ordre concret del fitxer, 
   * en fomat array.
   * 
   * @param raf Fitxer relatiu d'on llegir-lo
   * @param pos Posicio de l'adversari dins del fitxer
   * @return LLuitador llegit
   */
  public int[] crearAdversari(RandomAccessFile raf, int pos) {
    try {
      int[] adversari = new int[9];
      raf.seek(pos*50 + 30);
      adversari[0] = pos + 1;
      adversari[1] = raf.readInt();
      adversari[2] = raf.readInt();
      adversari[3] = raf.readInt();
      adversari[4] = adversari[3];
      adversari[5] = raf.readInt();
      adversari[6] = adversari[5];
      adversari[7] = raf.readInt();
      adversari[8] = adversari[7];
      return adversari;
    } catch (Exception e) {
      return null;
    }
  }

  /** Donat un fitxer relatiu orientat a byte, correctament posicionat,
   * llegeix el nom de l'adversari.
   *
   * @param raf Fitxer a tractar
   * @return Nom llegit, o null si hi ha errror
   */
  public String llegirNom(RandomAccessFile raf) {
    try {
      String nom = "";
      char c = raf.readChar();
      while (c != 0x0000) {
        nom = nom + c;
        c = raf.readChar();
      }
      return nom;
    } catch (Exception e) {
      return null;
    }
  }

 /**Donat un nivell, genera l'aversari corresponent a l'atzar. Es tracta
   * d'un adversari que sigui d'aquest nivell al menys.
   *
   * @param nivell nivell proper al de l'adversari a obtenir
   * @return Un adversari
   */
  public int[] triarAdversariAtzar(int nivell) {
    try {
      RandomAccessFile raf = new RandomAccessFile(ADVERSARIS,"r");
      Random rnd = new Random();

      int numAdv = (int)raf.length()/50;
      int[] adversari = null;
      boolean cercar = true;

      while (cercar) {
        int i = rnd.nextInt(numAdv);
        adversari = crearAdversari(raf, i);;
        int nivellAdv = lluitador.llegirNivell(adversari);
        int dif = nivell - nivellAdv;
        if ((dif >= -1)&&(dif <= 1)) {
          cercar = false;
        }
      }
      
      raf.close();
      return adversari;
    } catch (Exception e)  {
      return null;
    }
  }

  /** Transforma un identificador de Lluitador al seu nom.
   *
   * @param id Identificador
   * @return La cadena de text amb el nom.
   */
  public String traduirIDANom(int id) {
    if (id == 0)  {
      return "Aventurer";
    }
    id--;
    try {
      RandomAccessFile raf = new RandomAccessFile(ADVERSARIS, "r");
      int pos = 50*id;
      String nom = "DESCONEGUT";
      if (pos < raf.length()) {
        raf.seek(pos);
        nom = llegirNom(raf);
      }
      raf.close();
      return nom;
    } catch (Exception e) {
      return "DESCONEGUT";
    }
  }

  /** Diu si existeix el fitxer d'adversaris
   * 
   * @return Si existeix (true) o no (false)
   */
  public boolean existeixFitxer() {
    return ADVERSARIS.isFile();
  }

}
