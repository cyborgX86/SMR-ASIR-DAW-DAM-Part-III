package joc.arena.regles;

public class CombatAntic {

  //Constants que indiquen possibles accions de combat
  public static final int ATAC = 0;
  public static final int DEFENSA = 1;
  public static final int ENGANY = 2;
  public static final int MANIOBRA = 3;

  /** Donat el codi d'una estrategia, el converteix a un text.
   *
   * @param accio Codi de l'estrategia
   * @return Text associat
   */
  public String estrategiaAText(int accio) {
    switch(accio) {
      case ATAC: return "ATAC";
      case DEFENSA: return "DEFENSA";
      case ENGANY: return "ENGANY";
      case MANIOBRA: return "MANIOBRA";
    }
    return "DESCONEGUDA";
  }

  /** Resol una ronda d'accions entre dos Lluitadors, d'acord amb les estrategies
   * individuals de cadascu.
   *
   * @param jug
   * @param accioJug
   * @param adv
   * @param accioAdv
   */
  public void resoldreEstrategies(int[] jug, int accioJug, int[] adv, int accioAdv) {

    if ((accioJug == ATAC)&&(accioAdv == ATAC)) {
      atacContraAtac(jug, adv);
    } else if ((accioJug == ATAC)&&(accioAdv == DEFENSA)) {
      atacContraDefensa(jug, adv);
    } else if ((accioJug == ATAC)&&(accioAdv == ENGANY)) {
      atacContraEngany(jug, adv);
    } else if ((accioJug == ATAC)&&(accioAdv == MANIOBRA)) {
      atacContraManiobra(jug, adv);
    } else if ((accioJug == DEFENSA)&&(accioAdv == ATAC)) {
      atacContraDefensa(adv, jug);
    } else if ((accioJug == DEFENSA)&&(accioAdv == DEFENSA)) {
      defensaContraDefensa(jug, adv);
    } else if ((accioJug == DEFENSA)&&(accioAdv == ENGANY)) {
      defensaContraEngany(jug, adv);
    } else if ((accioJug == DEFENSA)&&(accioAdv == MANIOBRA)) {
      defensaContraManiobra(jug, adv);
    } else if ((accioJug == ENGANY)&&(accioAdv == ATAC)) {
      atacContraEngany(adv, jug);
    } else if ((accioJug == ENGANY)&&(accioAdv == DEFENSA)) {
      defensaContraEngany(adv, jug);
    } else if ((accioJug == ENGANY)&&(accioAdv == ENGANY)) {
      enganyContraEngany(jug, adv);
    } else if ((accioJug == ENGANY)&&(accioAdv == MANIOBRA)) {
      enganyContraManiobra(jug, adv);
    } else if ((accioJug == MANIOBRA)&&(accioAdv == ATAC)) {
      atacContraManiobra(adv, jug);
    } else if ((accioJug == MANIOBRA)&&(accioAdv == DEFENSA)) {
      defensaContraManiobra(adv, jug);
    } else if ((accioJug == MANIOBRA)&&(accioAdv == ENGANY)) {
      enganyContraManiobra(adv, jug);
    } else if ((accioJug == MANIOBRA)&&(accioAdv == MANIOBRA)) {
      maniobraContraManiobra(jug, adv);
    } else {
      //No s'hauria de donar aquest cas...
    }

  }

  /** Resolucio quan els dos ataquen.
   *
   * @param primari Lluitador que ataca
   * @param secundari Lluitador que ataca
   */
  public void atacContraAtac(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarAtac(primari);
    int caresSecundari = per.tirarAtac(secundari);
    //Els dos danyen
    per.danyar(primari, caresSecundari);
    per.danyar(secundari, caresPrimari);
  }

  /** Resolucio quan un ataca i l'altre defensa.
   *
   * @param primari Lluitador que ataca
   * @param secundari Lluitador que defensa
   */
  public void atacContraDefensa(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarAtac(primari);
    int caresSecundari = per.tirarDefensa(secundari);
    //Secundari rep mal o es guareix
    if (caresPrimari > caresSecundari) {
      per.danyar(secundari, caresPrimari);
    } else {
      per.guarir(secundari, caresSecundari);
    }
  }

  /** Resolucio quan un ataca i l'altre enganya.
   *
   * @param primari Lluitador que ataca
   * @param secundari Lluitador que enganya
   */
  public void atacContraEngany(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarAtac(primari);
    //Secundari rep danys
    per.danyar(secundari, caresPrimari);
  }

  /** Resolucio quan un ataca i l'altre maniobra.
   *
   * @param primari Lluitador que ataca
   * @param secundari Lluitador que maniobra
   */
  public void atacContraManiobra(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarAtac(primari);
    int caresSecundari = per.tirarDefensa(secundari);
    //Secundari rep danys o primari es penalitzat
    if (caresPrimari > caresSecundari) {
      per.danyar(secundari, caresPrimari);
    } else {
      per.penalitzar(primari, caresSecundari);
    }

  }

  /** Resolucio quan un defensa i l'altre defensa.
   *
   * @param primari Lluitador que defensa
   * @param secundari Lluitador que defensa
   */
  public void defensaContraDefensa(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarDefensa(primari);
    int caresSecundari = per.tirarDefensa(secundari);
    //Els dos es guareixen
    per.guarir(primari, caresPrimari);
    per.guarir(secundari, caresSecundari);
  }

  /** Resolucio quan un defensa i l'altre enganya.
   *
   * @param primari Lluitador que defensa
   * @param secundari Lluitador que enganya
   */
  public void defensaContraEngany(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresSecundari = per.tirarAtac(secundari);
    //El defensor rep danys
    per.danyar(primari, caresSecundari);
  }

  /** Resolucio quan un defensa i l'altre maniobra.
   *
   * @param primari Lluitador que defensa
   * @param secundari Lluitador que defensa
   */
  public void defensaContraManiobra(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarDefensa(primari);
    int caresSecundari = per.tirarDefensa(secundari);
    //Primari es guareix o es penalitzat
    if (caresPrimari > caresSecundari) {
      per.guarir(primari, caresPrimari);
    } else {
      per.penalitzar(primari, caresSecundari);
    }
  }

  /** Resolucio quan un enganya i l'altre enganya.
   *
   * @param primari Lluitador que enganya
   * @param secundari Lluitador que enganya
   */
  public void enganyContraEngany(int[] primari, int[] secundari) {
    //Es com un atac
    atacContraAtac(primari, secundari);
  }

  /** Resolucio quan un enganya i l'altre maniobra.
   *
   * @param primari Lluitador que enganya
   * @param secundari Lluitador que maniobra
   */
  public void enganyContraManiobra(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarAtac(primari);
    int caresSecundari = per.tirarDefensa(secundari);
    //Secundari rep danys o primari es penalitzat
    if (caresPrimari > caresSecundari) {
      per.danyar(secundari, caresPrimari);
    } else if (caresPrimari < caresSecundari) {
      per.penalitzar(primari, caresSecundari);
    }
  }

  /** Resolucio quan un maniobra i l'altre maniobra.
   *
   * @param primari Lluitador que maniobra
   * @param secundari Lluitador que maniobra
   */
  public void maniobraContraManiobra(int[] primari, int[] secundari) {
    Lluitador per = new Lluitador();
    int caresPrimari = per.tirarDefensa(primari);
    int caresSecundari = per.tirarDefensa(secundari);
    //Els dos es penalitzen mutuament de manera automatica
    per.penalitzar(primari, caresSecundari);
    per.penalitzar(secundari, caresPrimari);
  }

}