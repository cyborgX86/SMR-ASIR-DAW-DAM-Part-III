package joc.arena.fitxers;

import java.io.File;
import java.io.PrintStream;
import java.util.Scanner;

public class Ranquing {

   //Nom fitxer com constant
   public static final String RANQUING = "Ranquing";

   /** Crea el fitxer de puntuacions inicial
    *
    * @return 0 si tot correcte, -1 si error
    */
   public int generarFitxerInicial() {
    try {
      File ranquing = new File(RANQUING);
      if (ranquing.isFile() == false) {
        PrintStream ps = new PrintStream(ranquing);
        for (int i = 0; i < 10; i++) {
          ps.println("IOC " + (10 - i)*10);
        }
        ps.close();
      }
      return 0;
    } catch (Exception e) {
      //Propagacio d'error
      return -1;
    }
   }

  /** Donada una puntuacio, estableix la seva posicio al fitxer
   * 
   * @param punts Punts que cal comprovar
   * @return posicio per la puntuacio. -1 Si error.
   */
  public int cercarRanking(int punts) {
    try {
      int err = generarFitxerInicial();
      if (err == -1) {
        return -1;
      }
      File ranquing = new File(RANQUING);
      Scanner lector = new Scanner(ranquing);
      int pos = 0;
      while (pos < 10) {
        String nom = lector.next();
        if (lector.hasNextInt()) {
          int ranqPts = lector.nextInt();
          if (punts > ranqPts) {
            return pos;
          }
        } else {
          //Error en el format del fitxer
          return -1;
        }
        pos++;
      }
      lector.close();
      return pos;
    } catch (Exception e) {
      return -1;
    }
    
  }

  /** Insereix una puntuacio al ranking
   *
   * @param inicials Inicials del jugador
   * @param punts Puntuacio assolida
   * @param pos Posicio dins el ranking, o -1 si hi ha error
   * @return 0 si tot correcte, -1 si error.
   */
  public int entrarPuntuacio(String inicials, int punts, int pos) {
    try {
      int err = generarFitxerInicial();
      if (err == -1) {
        return -1;
      }
      File ranquing = new File(RANQUING);
      Scanner lector = new Scanner(ranquing);
      File tmp = new File (RANQUING + ".tmp");
      PrintStream ps = new PrintStream(tmp);
      //Reescriure anteriors a posicio
      for(int i = 0; i < pos; i++) {
        String txt = lector.nextLine();
        ps.println(txt);
      }

      //Escriure nova puntuacio
      ps.println(inicials + " " + punts);

      //Reescriure posteriors a posicio
      for(int i = pos + 1; i < 10; i++) {
        String txt = lector.nextLine();
        ps.println(txt);
      }
      ps.close();
      lector.close();
      //S'eborra fitxer antic i es posa el nou
      ranquing.delete();
      tmp.renameTo(ranquing);
      return 0;
    } catch (Exception e) {
      return -1;
    }
  }
    
  /** Llegeis les puntuacions i les formata com una cadena de text
   *
   * @return Cadena de text resultant. null si hi ha error
   */
  public String llegirRanquing() {
    try {
      int err = generarFitxerInicial();
      if (err == -1) {
        return null;
      }
      String txtRanquing = "Ranquing de puntuacions\n----------------------\n";
      File ranquing = new File(RANQUING);
      Scanner lector = new Scanner(ranquing);
      for (int i = 0; i < 10; i++) {
        //Llegir inicials
        txtRanquing = txtRanquing + lector.next();
        //Llegir punts
        if (lector.hasNextInt()) {
          txtRanquing = txtRanquing + "\t" + lector.nextInt() + "\n";
        } else {
          //Error en el format del fitxer
          return null;
        }
      }
      lector.close();
      return txtRanquing;
    }  catch (Exception e) {
      return null;
    }
  }

}
