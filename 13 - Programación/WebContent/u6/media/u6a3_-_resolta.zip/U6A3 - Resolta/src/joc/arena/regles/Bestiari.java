package joc.arena.regles;

import java.util.Random;


public class Bestiari {

  //Taula de traduccio d'identificadors a noms
  private String[] noms = {"Aventurer",
                           "Nan", "Kobold",
                           "Orc", "Profund",
                           "Bruixot maligne", "Ogre",
                           "Guerrer del caos", "Troll",
                           "Elemental terrestre", "Hidra"};

  //Jugador: ID = 0
  private int[] jugador = {0,  1,  0, 10, 10, 3, 3, 3, 3};

  //Adversaris possibles al joc
  private int[][] adversaris = {
                               {1,  1, 25,  8,  8, 3, 3, 3, 3},
                               {2,  1, 30, 10, 10, 4, 4, 2, 2},
                               {3,  2, 35, 12, 12, 4, 4, 3, 3},
                               {4,  2, 40, 14, 14, 3, 3, 4, 4},
                               {5,  3, 45, 15, 15, 3, 3, 5, 5},
                               {6,  3, 50, 16, 16, 5, 5, 2, 2},
                               {7,  4, 55, 15, 15, 4, 4, 4, 4},
                               {8,  4, 60, 18, 18, 3, 3, 5, 5},
                               {9,  5, 70, 22, 22, 4, 4, 6, 6},
                               {10, 5, 80, 30, 30, 8, 8, 2, 2}
                               };

  private Lluitador lluitador = new Lluitador();

  /** Genera un nou jugador
   * 
   * @return Un array amb les dades d'un jugador inicial
   */
  public int[] generarJugador() {
    lluitador.renovar(jugador);
    return jugador;
  }

  /** Donat un nom, genera l'aversari corresponent. Si aquest nom no existeix,
   * es genera a l'atzar.
   *
   * @param nomAdv Nom de l'adversari a obtenir
   * @return El Lluitador amb aquest nom, o null si no existeix
   */
  public int[] cercarAdversari(String nomAdv) {
    for (int i = 0; i < adversaris.length; i++) {
     int id = lluitador.llegirId(adversaris[i]);
     String nom = traduirIDANom(id);
     if (nom.equalsIgnoreCase(nomAdv)) {
       lluitador.renovar(adversaris[i]);
       return adversaris[i];
     }
    }
    return null;
  }

  /**Donat un nivell, genera l'aversari corresponent a l'atzar. Es tracta
   * d'un adversari que sigui d'aquest nivell al menys.
   *
   * @param nivell nivell proper al de l'adversari a obtenir
   * @return Un adversari
   */
  public int[] triarAdversariAtzar(int nivell) {
    Random rnd = new Random();
    
    int[] adversari = null;
    boolean cercar = true;
    
    while (cercar) {
      int i = rnd.nextInt(adversaris.length);
      adversari = adversaris[i];
      int nivellAdv = lluitador.llegirNivell(adversari);
      int dif = nivell - nivellAdv;
      if ((dif >= -1)&&(dif <= 1)) {
        cercar = false;    
      }
    }

    //Es deixa a l'adversari nou de trinca, llest per lluitar
    lluitador.renovar(adversari);
    return adversari;
  }

  /** Transforma un identificador de Lluitador al seu nom.
   * 
   * @param id Identificador
   * @return La cadena de text amb el nom.
   */
  public String traduirIDANom(int id) {
    if ((id >= 0) && (id < noms.length)) {
      return noms[id];
    }
    return "DESCONEGUT";
  }

  //METODES PER RECURSIVITAT

  /** Donat l'array bidimensional amb ela adversaris, els ordenda pel nom
   * associat a cada identificador. Recordar que un array bidimensional es
   * cnsidera un "array d'arrays"
   */
  public void ordenarAdversaris() {
    for (int i = 0; i < adversaris.length; i++) {
      for (int j = i + 1; j < adversaris.length; j++) {

        int idI = lluitador.llegirId(adversaris[i]);
        String nomI = traduirIDANom(idI);
        nomI = nomI.toLowerCase();

        int idJ = lluitador.llegirId(adversaris[j]);
        String nomJ = traduirIDANom(idJ);
        nomJ = nomJ.toLowerCase();

        if (nomI.compareTo(nomJ) > 0) {
          //I > J. Cal intercanviar
          int midaArray = adversaris[i].length;
          int[] temp = new int[midaArray];
          copiarArray(adversaris[i], temp);
          copiarArray(adversaris[j], adversaris[i]);
          copiarArray(temp, adversaris[j]);
        }    
      }    
    }

  }

  /** Metoe auxilar per copiar els valors d'un array a un altre.
   *
   * @param origen Array origen
   * @param desti Array desti
   */
  public void copiarArray(int[] origen, int[] desti) {
    for (int i=0; i < desti.length; i++) {
      desti[i] = origen[i];
    }
  }

  //RECURSIVITAT

  /** Inici de la cerca recursiva. Adapta la crida noral d'acord a la mida
   * de la llista d'adversaris.
   *
   * @param nomAdv Nom a cercar
   * @return Adversari (null si no es troba)
   */
  public int[] cercarAdversariR(String nomAdv) {
    return cercarAdversariRecursivament(nomAdv.toLowerCase(), 0, adversaris.length - 1);
  }

  /** Cerca recursiva real
   *
   * @param nomAdv Nom a cercar
   * @param inici Posicio inicial de la cerca
   * @param fi Posicio final de la cerca
   * @return Adversari trobat (o null si no es troba)
   */
  public int[] cercarAdversariRecursivament(String nomAdv, int inici, int fi) {
    int diferencia =  fi - inici;
    if (diferencia < 0) {
      //No s'ha trobat
      return null;
    } else {
      int posicio = inici + diferencia/2;
      int id = lluitador.llegirId(adversaris[posicio]);
      String nom = traduirIDANom(id);
      nom = nom.toLowerCase();
      
      int compara = nom.compareTo(nomAdv);
      if (compara == 0) {
        //Son iguals. Trobat!
        return adversaris[posicio];
      } else if (compara < 0) {
        //El nom de la llista es mes petit. Cal cercar pels posteriors
        return cercarAdversariRecursivament(nomAdv, posicio + 1,fi);
      } else {
        //El nom de la llista es mes gran. Cal cercar pels anteriors
        return cercarAdversariRecursivament(nomAdv, inici, posicio - 1);
      }
    }
  }

}
