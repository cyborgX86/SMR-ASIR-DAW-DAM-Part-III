import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

//Interfície gràfica
public class CalculadoraGUI {

    private Calculadora calculadora;
    private JFrame frame;
    private JLabel display;

    //Als botons de números s'usa un mateix Listener per tots (una única instància), ja que en aquest cas 
    //el codi és exactament igual per tots. Per aixo es defineix una classe privada i no anònima. 
    private class BotoNumeroListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        JButton botoPitjat = (JButton)e.getSource();  
        calculadora.pitjarNumero(Integer.parseInt(botoPitjat.getText()));
        display.setText(Float.toString(calculadora.getDisplay()));
      } 
    }

    public static void main (String args[]) {
      CalculadoraGUI gui = new CalculadoraGUI(new Calculadora());
    }

    public CalculadoraGUI(Calculadora model) {
        calculadora = model;
        makeFrame();
        frame.setVisible(true);
    }
    
    private void makeFrame() {
        //Crear contenidor d'alt nivell. finestra
        frame = new JFrame("Calculadora");

        //Obtenir panell contenidor i assignar layout        
        JPanel panell = (JPanel)frame.getContentPane();
        panell.setLayout(new BorderLayout(8, 8));
        panell.setBorder(new EmptyBorder( 10, 10, 10, 10));

        //Crear display i afegir-lo, a la vora superior
        display = new JLabel(Float.toString(calculadora.getDisplay()));
        display.setHorizontalAlignment(SwingConstants.RIGHT);
	display.setOpaque(true);
	display.setBackground(Color.WHITE); 
	panell.add(display, BorderLayout.NORTH);

        //Crear panell de botons complet. S'usa un bucle, enlloc de 16 crides individuals.
        JPanel panellBotons = new JPanel(new GridLayout(4, 4));
        String[] valors = {"7","8","9","+","4","5","6","-","1","2","3","*","0","C","=","/"};
        JButton[] botons = new JButton[valors.length];
        for (int i=0;i<valors.length;i++) {
          botons[i] = new JButton(valors[i]);
          panellBotons.add(botons[i]);
        } 
 
	//S'instancia el Listener comú per tots els botons numèrics
        ActionListener botoNumeroListener = new BotoNumeroListener();
        //S'afegeixen els listeners a cadascun dels botons
        for (int i=0;i<valors.length;i++) {
          switch(i) {
            case 3:  //Cas +
              botons[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                  calculadora.pitjarOperacio(Calculadora.SUMA);
                  display.setText(Float.toString(calculadora.getDisplay()));
                } 
              });
              break;
            case 7:  //Cas -
              botons[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                  calculadora.pitjarOperacio(Calculadora.RESTA);
                  display.setText(Float.toString(calculadora.getDisplay()));
                } 
              });
              break;
            case 11: //Cas *
              botons[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                  calculadora.pitjarOperacio(Calculadora.MULTIPLICA);
                  display.setText(Float.toString(calculadora.getDisplay()));
                } 
              });
              break;
            case 13: //Cas C
              botons[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                  calculadora.reset();
                  display.setText(Float.toString(calculadora.getDisplay()));
                } 
              });
              break;
            case 14: //Cas =
              botons[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                  calculadora.resultat();
                  display.setText(Float.toString(calculadora.getDisplay()));
                } 
              });
              break;
            case 15: //Cas /
              botons[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) { 
                  calculadora.pitjarOperacio(Calculadora.DIVIDEIX);
                  display.setText(Float.toString(calculadora.getDisplay()));
                } 
              });
              break;
            default: //Cas Numero 0-9. Tot comparteixen el mateix Listener.
              botons[i].addActionListener(botoNumeroListener);
          }
        } 
   
        //Afegir panell de botons al panell de contingut, centrat 
        panell.add(panellBotons, BorderLayout.CENTER);

        //Registrar el Listener que gestiona el tancament de la finestra amb una classe anònima
        frame.addWindowListener(new WindowAdapter(){ 
          public void windowClosing(WindowEvent e) { System.exit(0); }
        }); 

        //Considerar interface finalitzada
        frame.pack();
    }
}
