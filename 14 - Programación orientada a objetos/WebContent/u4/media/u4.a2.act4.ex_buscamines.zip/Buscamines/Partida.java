import java.util.*;

public class Partida {

  private Taulell taulellJugador;     //Taulel que veu el jugador
  private List<CoordenadaMina> mines ; //Llista de mines al taulell (visibles o no)
  private int casellesPendents;       //Nombre de caselles pendents per acabar el joc
  private int minesPendents;
  
  private ActualitzadorInterface updater; //Responsable d'actualitzar els canvis del Model a la Vista.

  //Constructor. Nova partida.
  public Partida(int dim, int numMines) {
    //Inicialitzem atributs
    casellesPendents = dim*dim;  
    minesPendents = numMines;
    taulellJugador = new Taulell(dim);
    //Ubiquem mines a l'atzar, vigilant de no repetir caselles
    mines = new ArrayList<CoordenadaMina>();
    if (numMines > dim*dim - dim) numMines = numMines - dim; //Si ens passem de mines, serà un bucle infinit.
    for (int i=0;i<numMines;i++) {
      CoordenadaMina m = new CoordenadaMina(dim);
      if (mines.contains(m)) { i--;
      } else { mines.add(m); }
    }
  }

  //Obrim una casella. Retorna cert si el joc ha acabat
  public boolean obrirPosicio(int x, int y) {
    int val = taulellJugador.getValor(x,y);
    if ((val < 9)||(val == Taulell.BANDERA)) return false; //Coordenada no valida,casella ja oberta, o marcada. No fer res
    CoordenadaMina m = new CoordenadaMina(x,y);
    if (mines.contains(m)) { //Comprovar si hi ha una mina
      taulellJugador.setValor(x,y,Taulell.MINA);
      val = Taulell.MINA;
      minesPendents--;
    } else { //No hi ha una mina  
      val = calcMines(x,y); //Quantes mines ens envolten?
      taulellJugador.setValor(x,y,val); 
      if (val == 0) { //Si no ens envolta cap...podem obrir automàticament casellles pendents dels voltants.              
        for (int i = x-1; i <= x+1; i++)
          for (int j = y-1; j <= y+1; j++)
            if (((x != i)||(y!=j))&&(taulellJugador.getValor(i,j) == Taulell.PENDENT))
              obrirPosicio(i,j);        

      }
    }
    updater.mostrarValor(x,y,val); 
    casellesPendents--;    
    return ((casellesPendents <= minesPendents)||(minesPendents == 0));
  } 

  //Marcar/desmarcar amb una bandera una casella
  public void marcarPosicio(int x, int y) {
    int val = taulellJugador.getValor(x,y);
    int nouEstat = Taulell.ERROR;
    if (val == Taulell.PENDENT) nouEstat = Taulell.BANDERA; 
    if (val == Taulell.BANDERA) nouEstat = Taulell.PENDENT; 
    if (nouEstat != Taulell.ERROR) {
      taulellJugador.setValor(x,y,nouEstat); 
      updater.mostrarValor(x,y,nouEstat);
    }    
  } 

  //Consulta l'estat d'una casella
  public int obtenirPosicio(int x, int y) {
    return taulellJugador.getValor(x,y);
  }

  //Mètode auxiliar. Calcula quantes mines hi ha al voltant d'una casella
  private int calcMines(int x, int y) {
    int numMines = 0;  //Per cada casella cirundant mirem si hi ha una mina a dins.
    for (int i = x-1; i <= x+1; i++)
      for (int j = y-1; j <= y+1; j++)
        if ((x != i)||(y!=j)) {
          CoordenadaMina m = new CoordenadaMina(i,j);
          if (mines.contains(m)) numMines++;
        }
    return numMines;
  }

  //Retorna la puntuacio
  public int obtenirPunts() {
    return minesPendents*taulellJugador.getDimensio();
  }

  //Registra al responsable d'actualitzar la Vista d'acord al Model cada cop que hi ha un canvi.
  public void registrarActualitzador(ActualitzadorInterface ai) {
    updater = ai; 
  }

}
