import java.util.Random;

//Una coordenada d'una mina.
public class CoordenadaMina {

  private static final Random rnd = new Random();

  private int x;
  private int y;

  //Constructor per ubicacio aleatòria.
  public CoordenadaMina(int dim) {
    x = rnd.nextInt(dim);
    y = rnd.nextInt(dim);
  }

  //Constructor per ubicacio personalitzada.
  public CoordenadaMina(int x, int y) {
    this.x = x;
    this.y = y;
  }

  //Cal sobreescriure el mètode "equals" per poder usar els metodes de cerca d'una llista (exists).  
  public boolean equals (Object o) {
    CoordenadaMina m = (CoordenadaMina)o;
    return ((m.x == this.x)&&(m.y == this.y));
  }

}

