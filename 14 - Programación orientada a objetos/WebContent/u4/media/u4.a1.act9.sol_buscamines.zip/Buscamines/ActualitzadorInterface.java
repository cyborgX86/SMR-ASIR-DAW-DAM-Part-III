public interface ActualitzadorInterface {

  public void mostrarValor(int x, int y, int val);
  
}
