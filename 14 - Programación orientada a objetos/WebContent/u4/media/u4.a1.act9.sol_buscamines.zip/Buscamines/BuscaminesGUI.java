import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

//Interficie grafica.
//MOLT IMPORTANT: L'estat de la partida s'ha de deduir exclusivament del Model, mai per l'estat dels
//elements gràfcis de la interfíce.
public class BuscaminesGUI extends JFrame {

  private Partida model;             //Model amb l'estat de la partida
  private Casella[][] caselles;      //Conjunt de caselles
  private int dim, numMines;         //Paràmetres del joc


  //Una casella de la graella. Es un JLabel al qual afegim informacio de les seves coordenades.
  //Al ser una classe privada, ens podem permetre usar atributs publics.
  private class Casella extends JLabel {
    public int x;
    public int y;

    //Constructor
    public Casella(int x, int y) {
      super();
      this.x = x;
      this.y = y;
      setVerticalAlignment(SwingConstants.CENTER);
      setHorizontalAlignment(SwingConstants.CENTER);
      setPreferredSize(new Dimension(30,30));
    }
  }

  //Listener de les interaccions del ratolí amb una casella. Capturem quan es pitja el ratolí.
  private class CasellaListener extends MouseAdapter {
    public void mouseClicked(MouseEvent e) {
      Casella c = (Casella)e.getSource();
      switch (e.getButton()) {
        case MouseEvent.BUTTON1:  //Obrim el quadre si està pendent, sinó no fem res          
            boolean end = model.obrirPosicio(c.x,c.y); //Nomes cal obrir. El Model ja avisa a la Vista pq s'actualitzi.
            if (end) {
              JOptionPane.showMessageDialog(null,"Fi de la Partida! Puntuacio:" + model.obtenirPunts());
              novaPartida();
            }
          break;
        case MouseEvent.BUTTON3:  //Posar/treure bandera si quadre està pendent, sinó res
          model.marcarPosicio(c.x,c.y);  //No cal fer cap control de l'estat de la casella. Ja ho fa el model.
          actualitzarCasella (c, model.obtenirPosicio(c.x,c.y));
          break;
        default:
      }
    } 
  }

  //Via perque la Vista actualitzar l'estat de les caselles de manera transparent.
  private class ActualitzadorCasella implements ActualitzadorInterface {
    public void mostrarValor(int x, int y, int val) {
      if ((x>=0)&&(x<caselles.length)&&(y>=0)&&(y<caselles[x].length)) {
        actualitzarCasella(caselles[x][y], val);
      }
    }
  }

  //Modifica l'aspecte d'una casella d'acord al seu contingut 
  private void actualitzarCasella(Casella c, int val) {
    int borderType = EtchedBorder.LOWERED;
    switch(val) {
      case 0: c.setText(""); break;
      case Taulell.PENDENT: c.setText(""); borderType = EtchedBorder.RAISED; break; 
      case Taulell.BANDERA: c.setText("!"); c.setForeground(Color.BLUE); borderType = EtchedBorder.RAISED; break; 
      case Taulell.MINA: c.setText("*"); c.setForeground(Color.RED); break; 
      default: c.setText(Integer.toString(val));
    }
    c.setBorder(new BevelBorder(borderType));
  }

  //Genera una nova partida: crea un nou Model i reseteja les caselles de la GUI.
  private void novaPartida () {
   //Generem un nou model
   model = new Partida(dim, numMines);
   model.registrarActualitzador(new ActualitzadorCasella());   
   for (int i = 0; i < caselles.length; i++)
    for (int j = 0; j < caselles[i].length; j++) {
      caselles[i][j].setText("");
      caselles[i][j].setBorder(new BevelBorder(EtchedBorder.RAISED));
      caselles[i][j].setForeground(Color.BLACK);
    }
  }

  //Mètode Principal
  public static void main (String args[]) {    
    int dim = 0 , numMines = 0;
    while (dim == 0) {
      String res = JOptionPane.showInputDialog(null,"Dimensió del Panell?", "10");
      try {dim = Integer.parseInt(res); } catch (Exception ex) { dim = 0; }
    }
    while (numMines == 0) {
      String res = JOptionPane.showInputDialog(null,"Quantitat de mines?", Integer.toString(dim));
      try {numMines = Integer.parseInt(res); } catch (Exception ex) { numMines = 0; }
    }    
    if (numMines > (dim*dim - dim)) {
      numMines = dim*dim - dim;
      JOptionPane.showMessageDialog(null, "Hi ha masses mines. Es posaran " + numMines); 
    }
    new BuscaminesGUI(dim, numMines);
  }

  public BuscaminesGUI(int d, int n) {
    super("Buscamines");
    dim = d;
    numMines = n; 
    JPanel panell = (JPanel)getContentPane();
    //Generem el contingut. Una graella de dim*dim caselles.
    panell.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.RAISED), "Panell de Joc"));
    panell.setLayout(new GridLayout(dim,dim,5,5));
    CasellaListener bal = new CasellaListener();
    caselles = new Casella[dim][dim];
    for (int i = 0; i < dim; i++)
      for (int j = 0; j < dim; j++) {        
        caselles[i][j] = new Casella(i,j);
        caselles[i][j].addMouseListener(bal);
        panell.add(caselles[i][j]);
      }
    addWindowListener(new WindowAdapter(){ 
      public void windowClosing(WindowEvent e) { System.exit(0); }
    }); 
    //Generem una nova partida
    novaPartida();
    setVisible(true);
    pack();
  }
 
}
