public class Taulell {

  //Valors especials per una casella. 
  //La resta de valors (0-8) son una casella oberta amb el nombre mines que l'envolten.
  public static final int ERROR   = -1; //S'ha accedit a una posicio invàlida (fora de les dimensions) 
  public static final int PENDENT = 9;  //Casella pendent d'obrir
  public static final int MINA    = 10; //Casella oberta amb una mina
  public static final int BANDERA = 11; //Casella pendent d'obrir amb una bandera

  private int[][] taulell;

  //Constructor. Crea un taulell de dim*dim caselles, totes elles pendents d'obrir
  public Taulell(int dim) {
    taulell = new int[dim][dim];
    for (int i = 0; i < dim; i++)
      for (int j = 0; j < dim; j++)
        taulell[i][j] = PENDENT;
  }

  //Retorna la dimensio del taulell
  public int getDimensio() {
    return taulell.length;
  }
  
  //Asigna un valor a una casella. Si la posició es invàlida no fa res.    
  public void setValor(int x, int y, int val) { 
    if (coordenadaValida(x,y))
      taulell[x][y] = val;
  }

  //Es consulta l'estat d'una casella. Si la posició es invàlida retirna error.
  public int getValor(int x, int y) { 
    if (coordenadaValida(x,y))
      return taulell[x][y];
    return ERROR; 
  }

  //Metode auxiliar per validar coordenades
  public boolean coordenadaValida(int x, int y) {
    return ((x >= 0)&&(x < taulell.length)&&(y >= 0)&&(y < taulell[x].length));
  }

}

