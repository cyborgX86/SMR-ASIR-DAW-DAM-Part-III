package utilitats;


public class Algorismes {

  public static void ordenar(Comparable[] figs) {
    for (int i = 0; i < figs.length; i++) {
      for (int j = i; j < figs.length; j++) {
        if (figs[i].compareTo(figs[j]) == 1) {
          Comparable c = figs[i];
          figs[i] = figs[j];
          figs[j] = c;
        }
      }
    }
  }
}
