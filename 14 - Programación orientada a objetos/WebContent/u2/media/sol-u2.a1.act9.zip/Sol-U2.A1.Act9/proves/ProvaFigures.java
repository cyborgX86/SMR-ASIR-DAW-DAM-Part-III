package proves;

import java.awt.Color;
import utilitats.Algorismes;
import figures.*;

public class ProvaFigures {

  public static void main (String[] args) {
    FiguraGeometrica[] figs = {new Cercle (1, "Cercle 1", Color.green, 42.42),
                               new Rectangle (2, "Rectangle 1", Color.green, 3,4),
                               new Triangle (3, "Triangle 1", Color.yellow, 3,4),
                               new Cercle (1, "Cercle 1", Color.red, 8.5)
    };

    System.out.println("Abans d'ordenar:\n---------------");
    for (int i = 0; i < figs.length; i++) {
      figs[i].visualitzar();
    }

    Algorismes.ordenar(figs);

    System.out.println("després d'ordenar:\n---------------");
    for (int i = 0; i < figs.length; i++) {
      figs[i].visualitzar();
    }


  }
}
