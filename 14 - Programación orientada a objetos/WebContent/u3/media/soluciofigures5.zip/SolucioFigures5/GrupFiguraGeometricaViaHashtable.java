package figures;
import java.util.Hashtable;
import java.util.Enumeration;

public class GrupFiguraGeometricaViaHashtable {
   private Hashtable<Integer,FiguraGeometrica02> ht;
   
   public GrupFiguraGeometricaViaHashtable(int dim)   {
      if (dim<0) throw new IllegalArgumentException("Dimensi� err�nia: " + dim);
      ht = new Hashtable<Integer,FiguraGeometrica02>(dim);
   }
   
   public GrupFiguraGeometricaViaHashtable()   {
      ht = new Hashtable<Integer,FiguraGeometrica02>();;
   }

   public int nreElements()   {
      return ht.size();
   }
   
   /** Afegeix, si no hi ha cap objecte amb id�ntica clau, l'objecte obj a la Hashtable
       Retorna 0: S'ha afegit sense cap problema
               -1: No s'ha pogut afegir per haver-hi ja un element amb la mateixa clau (codi)
               -2: S'ha intentat afegir una refer�ncia null
   */
   public int afegir(FiguraGeometrica02 obj)   {
      int i;
      if (obj==null) return -2;
      if (ht.get(obj.codi)!=null) return -1;
      ht.put(obj.codi, obj);
      return 0;
   }

   /** Cerca un objecte dins el grup amb codi id�ntic a a l'indicat
       Retorna : Una refer�ncia a l'objecte, si el troba
                 Null, si no el troba
   */
   public FiguraGeometrica02 cercar(int codi)   {
      return ht.get(codi);
   }

   /** Cerca un objecte dins la taula amb codi id�ntic a l'indicat per a treure'l del grup
       Retorna : Una refer�ncia a l'objecte, si el troba
                 Null, si no el troba
   */
   public FiguraGeometrica02 extreure(int codi)   {
      return ht.remove(codi);
   }

   public void buidar()   {
      ht.clear();
   }

   public void visualitzar()   {
      Enumeration<FiguraGeometrica02> efg;
      System.out.println ("Contingut de la hashtable");
      System.out.println ("*************************");
      System.out.println ("Nre. Elements: " + ht.size());
      efg = ht.elements();
      while (efg.hasMoreElements())
         System.out.println (efg.nextElement());
   }
   
   public boolean equals(Object obj)   {
      if (this == obj) return true;
      if (obj == null) return false;
      if (obj instanceof GrupFiguraGeometricaViaHashtable) 
         return ht.equals(((GrupFiguraGeometricaViaHashtable)obj).ht);
      return false;
   }

   public int hashCode ()   {
      return ht.hashCode();
   }
}
