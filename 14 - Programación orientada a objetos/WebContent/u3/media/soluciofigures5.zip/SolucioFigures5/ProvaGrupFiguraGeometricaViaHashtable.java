package proves;
import java.awt.Color;
import figures.*;

public class ProvaGrupFiguraGeometricaViaHashtable {
   private static void missatgeAfegir (int error, FiguraGeometrica02 obj)   {
      System.out.println ("Afegir l'objecte " + obj);
      if (error==0) System.out.println("   Afegit.");
      else if (error==-2) System.out.println("   No afegit per ser null.");
      else System.out.println("   Codi "+obj.getCodi()+" existent en el grup");
   }
   
   public static void main(String args[])   {
      GrupFiguraGeometricaViaHashtable tfg= new GrupFiguraGeometricaViaHashtable(50);
      Rectangle02 r1 = new Rectangle02(35,"Rectangle35", Color.yellow, 4.3, 3.2);
      Triangle02 t1 = new Triangle02(21,"Triangle21", Color.red, 8.6, 2.2);
      Cercle02 c1 = new Cercle02(42,"Cercle42", Color.white, 5.2);
      Rectangle02 r2 = new Rectangle02(90,"Rectangle90", Color.pink, 5.1, 4.2);
      Triangle02 t2 = new Triangle02(10,"Triangle10", Color.orange, 3.6, 4.2);
      Cercle02 c2 = new Cercle02(3,"Cercle03", Color.gray, 3.2);
      FiguraGeometrica02 aux;

      System.out.println("Procedim a afegir alguns elements al grup.");
      missatgeAfegir(tfg.afegir(r1), r1);
      missatgeAfegir(tfg.afegir(t1), t1);
      missatgeAfegir(tfg.afegir(c1), c1);
      missatgeAfegir(tfg.afegir(r2), r2);
      missatgeAfegir(tfg.afegir(t2), t2);
      missatgeAfegir(tfg.afegir(c2), c2);
      System.out.println();
      tfg.visualitzar();
      System.out.println();
      System.out.println("Procedim a cercar la figura amb codi 42:");
      aux=tfg.cercar(42);
      if (aux!=null) {  
         System.out.println("Hem trobat la figura:");
         aux.visualitzar();
      } else {  
        System.out.println("No existeix cap figura amb el codi indicat.");
      }
      System.out.println();
      System.out.println("Procedim a cercar la figura amb codi 50:");
      aux=tfg.cercar(50);
      if (aux!=null) {  
         System.out.println("Hem trobat la figura:");
         aux.visualitzar();
      } else {  
        System.out.println("No existeix cap figura amb el codi indicat.");
      }
   }
}
