package figures;
import java.awt.Color;
import utilitats.AlgorismesHash;
import java.util.*;

public abstract class FiguraGeometrica04 implements Comparable<Object> {
   protected int codi=0;
   protected String nom="";
   protected Color color=Color.white;

   public FiguraGeometrica04 (int ncodi, String nnom, Color ncolor) {
      if (ncodi>0) codi = ncodi;
      nom = nnom;
      color = ncolor;
   }

   public FiguraGeometrica04(FiguraGeometrica04 f) {
      this (f.codi, f.nom, f.color);
   }

   public FiguraGeometrica04 () {}

   public void setCodi(int nouCodi) {
      if (nouCodi>=0) codi = nouCodi;
   }

   public void setNom (String nouNom) {
      nom = nouNom;
   }

   public void setColor (Color nouColor) {
      color = nouColor;
   }   

   public int getCodi () {
      return codi;
   }

   public String getNom () {
      return nom;
   }
   
   public Color getColor () {
      return color;
   }

   public void visualitzar () {
      System.out.println ("Codi..........:" + codi);
      System.out.println ("Nom...........:" + nom);
      System.out.println ("Color.........:" + color);
   }

   public boolean equals (Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (obj instanceof FiguraGeometrica04) return codi == ((FiguraGeometrica04)obj).codi;
      return false;
   }

   public int hashCode () {
      return AlgorismesHash.genericHash((new Integer(codi)).hashCode());
   }
   
   public String toString () {
      return codi + " - " + nom + " - �rea = " + area();
   }

   public abstract double area ();
   
   public int compareTo(Object obj) {
      return codi-((FiguraGeometrica04)obj).codi;
   }
   
   public static class ComparatorFiguraGeometricaSegonsArea implements Comparator<FiguraGeometrica04> {
      public int compare (FiguraGeometrica04 f1, FiguraGeometrica04 f2) {
         double result = f1.area()-f2.area();
         if (result<0) return -1;   // Cas en que f1.area() < f2.area();
         if (result>0) return 1;    // Cas en que f1.area() > f2.area();
         return 0;                  // Cas en que f1.area() i f2.area() s�n iguals
      }
   }
}