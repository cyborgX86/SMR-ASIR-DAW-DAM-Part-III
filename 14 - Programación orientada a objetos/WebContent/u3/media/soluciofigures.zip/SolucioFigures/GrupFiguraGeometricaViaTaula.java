package figures;
import java.util.Arrays;

public class GrupFiguraGeometricaViaTaula {
   private FiguraGeometrica04 t[];      
   private int q=0;
   
   public GrupFiguraGeometricaViaTaula(int dim) {
      if (dim<=0) throw new NegativeArraySizeException("Dimensi� err�nia: " + dim);
      t = new FiguraGeometrica04[dim];
   }
   
   public GrupFiguraGeometricaViaTaula() {
      this (10);
   }

   public int capacitat() {
      return t.length;
   }
   
   public int nreElements() {
      return q;
   }
   
   /** Afegeix, si no hi ha cap objecte amb id�ntica clau, l'objecte obj a la taula
       Retorna -1: S'ha afegit sense cap problema
               -2: S'ha passat una refer�ncia nul�la - No es pot afegir
               -3: No hi ha espai a la taula
              >=0: Ja existeix un objecte amb igual clau a la posici� retornada per la funci�
   */
   public int afegir(FiguraGeometrica04 obj) {
      int i;
      if (obj==null) return -2;
      for (i=0; i<q && t[i].equals(obj)==false; i++);
      if (i<q) return i;
      if (q==t.length) return -3;
      t[q] = obj;
      q++;
      return -1;
   }

   /** Cerca un objecte dins la taula amb codi id�ntic a a l'indicat
       Retorna -1: Si no el troba
                >=0: La posici� on hi ha un objecte amb id�ntic codi
   */
   public int cercar(int codi) {
      int i;
      for (i=0; i<q && t[i].codi!=codi; i++);
      if (i<q) return i;
      return -1;
   }

   /** Retorna l'objecte que esta a la posicio i
       Retorna null: Si la posicio no existeix o est� buida
   */
   public FiguraGeometrica04 exemplarAt(int i) {
      if (i<0 || i>=q) return null;      
      return t[i];
   }
   
   /** Cerca un objecte dins la taula amb codi id�ntic a l'indicat per a treure'l de la taula
       Retorna null: Si no el troba
               L'objecte extret en cas de trobar-lo
   */
   public FiguraGeometrica04 extreure(int codi) {
      int i;
      FiguraGeometrica04 aux;
      for (i=0; i<q && t[i].codi!=codi;i++);
      if (i==q) return null;
      aux = t[i];
      for (; i<q-1; i++) t[i]=t[i+1];
      t[q-1]=null;   // Per a que la figura geom�trica no quedi apuntada innecess�riament
      q--;
      return aux;
   }

   public void buidar() {
      int i;
      for (i=0; i<q; i++) t[i]=null;
      q=0;
   }

   public void visualitzar() {
      int i;
      System.out.println ("Contingut de la taula");
      System.out.println ("*********************");
      System.out.println ("Capacitat....: " + t.length);
      System.out.println ("Nre. Elements: " + q);
      for (i=0; i<q; i++)
         System.out.println("Element " + i + ": " + t[i]);
   }
   
   public void ordenarPerCodi() {
      Arrays.sort(t,0,q);
   }

   public void ordenarPerArea() {
      Arrays.sort(t,0,q,new FiguraGeometrica04.ComparatorFiguraGeometricaSegonsArea());
   }   

   public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (obj instanceof GrupFiguraGeometricaViaTaula)  {
         GrupFiguraGeometricaViaTaula aux = (GrupFiguraGeometricaViaTaula)obj;
         int i;
         if (q!=aux.q) return false;
         for (i=0; i<q && aux.cercar(t[i].codi)>=0; i++);
         if (i==q) return true; // Vol dir que totes les figures de t tenen un objecte "igual" segons el 
                                // m�tode FiguraGeometrica.equals() a l'altre grup obj
      }
      return false;
   }

   public int hashCode () {
      int result=0;
      int i;
      for (i=0; i<q; i++) result = result + t[i].hashCode();
      return result;
      // �s clar que si dos grups s�n iguals (conjunt d'elements iguals), amb aquesta implementaci� de hashCode()
      // tamb� tindran el mateix hashCode(), tal i com ha de ser.
   }
}
