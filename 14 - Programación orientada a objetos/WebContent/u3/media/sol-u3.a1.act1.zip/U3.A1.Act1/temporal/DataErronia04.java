package temporal;

public class DataErronia04 extends RuntimeException {
    public DataErronia04(int dia, int mes, int any) {
        super("La data "+dia+"/"+mes+"/"+any+" és invàlida.");
    }
}
