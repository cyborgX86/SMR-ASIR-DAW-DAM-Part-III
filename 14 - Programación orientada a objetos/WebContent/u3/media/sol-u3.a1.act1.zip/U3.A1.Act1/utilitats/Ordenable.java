package utilitats;

public interface Ordenable {
    public int comparar(Ordenable obj);
}
