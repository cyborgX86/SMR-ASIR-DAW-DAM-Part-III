package figures;
import java.util.Collections;
import java.util.Vector;

public class GrupOrdenatFiguraGeometricaViaVector{
   private Vector<FiguraGeometrica05> v;      
   
   public GrupOrdenatFiguraGeometricaViaVector(int dim)   {
      if (dim<0) throw new IllegalArgumentException("Dimensi� err�nia: " + dim);
      v = new Vector<FiguraGeometrica05>(dim);
   }
   
   public GrupOrdenatFiguraGeometricaViaVector()   {
      this (0);
   }

   public int capacitat()   {
      return v.capacity();
   }
   
   public int nreElements()   {
      return v.size();
   }
   
   /** Afegeix, si no hi ha cap objecte amb id�ntica clau, l'objecte obj a la taula
       Retorna -1: S'ha afegit sense cap problema
               -2: S'ha passat una refer�ncia nul�la - No es pot afegir
              >=0: Ja existeix un objecte amb igual clau a la posici� retornada per la funci�
   */
   public int afegir(FiguraGeometrica05 obj)   {
      int pos,i;
      if (obj==null) return -2;
      pos=Collections.binarySearch(v,obj);
      if (pos>=0) return pos;
      pos = -pos-1;  // Posici� on pertoca estar l'element a inserir
      v.add(pos,obj);
      return -1;
   }

   /** Cerca un objecte dins la taula amb codi id�ntic a a l'indicat
       Retorna  <0: Si no el troba, de manera que -valorDeRetorn-1 �s la posici� on hauria d'estar
                >=0: La posici� on hi ha un objecte amb id�ntic codi
   */
   public int cercar(int codi)   {
      int pos;
      return Collections.binarySearch(v,codi);
   }

   /** Retorna l'objecte que esta a la posicio i
       Retorna null: Si la posicio no existeix o est� buida
   */
   public FiguraGeometrica05 exemplarAt(int i)   {
      if (i<0 || i>=v.size()) return null;      
      return v.get(i);
   }
   
   /** Cerca un objecte dins la taula amb codi id�ntic a l'indicat per a treure'l de la taula
       Retorna null: Si no el troba
               L'objecte extret en cas de trobar-lo
   */
   public FiguraGeometrica05 extreure(int codi)   {
      int pos;
      pos=Collections.binarySearch(v,codi);
      if (pos<0) return null;
      return v.remove(pos);
   }

   public void buidar()   {
      v.clear();
   }
   
   public void visualitzar()   {
      int i;
      System.out.println ("Contingut del vector");
      System.out.println ("********************");
      System.out.println ("Capacitat....: " + v.capacity());
      System.out.println ("Nre. Elements: " + v.size());
      for (i=0; i<v.size(); i++)
         System.out.println("Element " + i + ": " + v.get(i));
   }
   
   public boolean equals(Object obj)   {
      if (this == obj) return true;
      if (obj == null) return false;
      if (obj instanceof GrupOrdenatFiguraGeometricaViaVector) 
         return v.equals(((GrupOrdenatFiguraGeometricaViaVector)obj).v);
      return false;
   }

   public int hashCode ()   {
      int result=0;
      int i;
      for (i=0; i<v.size(); i++) result = result + v.get(i).hashCode();
      return result;
      // �s clar que si dos grups s�n iguals (conjunt d'elements iguals), amb aquesta implementaci� de hashCode()
      // tamb� tindran el mateix hashCode(), tal i com ha de ser.
   }
}
