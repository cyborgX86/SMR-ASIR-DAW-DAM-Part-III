package figures;
import java.util.Arrays;

public class GrupOrdenatFiguraGeometricaViaTaula {
   private FiguraGeometrica05 t[];      
   private int q=0;
   
   public GrupOrdenatFiguraGeometricaViaTaula(int dim) {
      if (dim<=0) throw new NegativeArraySizeException("Dimensi� err�nia: " + dim);
      t = new FiguraGeometrica05[dim];
   }
   
   public GrupOrdenatFiguraGeometricaViaTaula() {
      this (10);
   }

   public int capacitat() {
      return t.length;
   }
   
   public int nreElements() {
      return q;
   }
   
   /** Afegeix, si no hi ha cap objecte amb id�ntica clau, l'objecte obj a la taula
       Retorna -1: S'ha afegit sense cap problema
               -2: S'ha passat una refer�ncia nul�la - No es pot afegir
               -3: No hi ha espai a la taula
              >=0: Ja existeix un objecte amb igual clau a la posici� retornada per la funci�
   */
   public int afegir(FiguraGeometrica05 obj) {
      int pos,i;
      if (obj==null) return -2;
      pos=Arrays.binarySearch(t,0,q,obj);
      if (pos>=0) return pos;
      if (q==t.length) return -3;
      pos = -pos-1;  // Posici� on pertoca estar l'element a inserir
      for (i=q; i>pos; i--) t[i]=t[i-1];  // Fem espai per inserir
      t[pos] = obj;
      q++;
      return -1;
   }

   /** Cerca un objecte dins la taula amb codi id�ntic a a l'indicat
       Retorna  <0: Si no el troba, de manera que -valorDeRetorn-1 �s la posici� on hauria d'estar
                >=0: La posici� on hi ha un objecte amb id�ntic codi
   */
   public int cercar(int codi) {
      int pos;
      return Arrays.binarySearch(t,0,q,codi);
   }

   /** Retorna l'objecte que esta a la posicio i
       Retorna null: Si la posicio no existeix o est� buida
   */
   public FiguraGeometrica05 exemplarAt(int i) {
      if (i<0 || i>=q) return null;      
      return t[i];
   }
   
   /** Cerca un objecte dins la taula amb codi id�ntic a l'indicat per a treure'l de la taula
       Retorna null: Si no el troba
               L'objecte extret en cas de trobar-lo
   */
   public FiguraGeometrica05 extreure(int codi) {
      FiguraGeometrica05 aux;
      int pos;
      pos=Arrays.binarySearch(t,0,q,codi);
      if (pos<0) return null;
      aux = t[pos];
      for (; pos<q-1; pos++) t[pos]=t[pos+1];
      t[q-1]=null;   // Per a que la figura geom�trica no quedi apuntada innecess�riament
      q--;
      return aux;
   }

   public void buidar() {
      int i;
      for (i=0; i<q; i++) t[i]=null;
      q=0;
   }
   
   public void visualitzar() {
      int i;
      System.out.println ("Contingut de la taula");
      System.out.println ("*********************");
      System.out.println ("Capacitat....: " + t.length);
      System.out.println ("Nre. Elements: " + q);
      for (i=0; i<q; i++)
         System.out.println("Element " + i + ": " + t[i]);
   }
   
   public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (obj instanceof GrupOrdenatFiguraGeometricaViaTaula){
         GrupOrdenatFiguraGeometricaViaTaula aux = (GrupOrdenatFiguraGeometricaViaTaula)obj;
         int i;
         if (q!=aux.q) return false;
         for (i=0; i<q && t[i].equals(aux.t[i]); i++);
         if (i==q) return true; // Vol dir que totes les figures de t s�n iguals (dos a dos) amb les figures
                                // de l'altre grup obj
      }
      return false;
   }

   public int hashCode () {
      int result=0;
      int i;
      for (i=0; i<q; i++) result = result + t[i].hashCode();
      return result;
      // �s clar que si dos grups s�n iguals (conjunt d'elements iguals), amb aquesta implementaci� de hashCode()
      // tamb� tindran el mateix hashCode(), tal i com ha de ser.
   }
}
