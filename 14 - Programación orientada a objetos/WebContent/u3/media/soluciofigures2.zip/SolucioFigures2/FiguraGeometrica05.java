package figures;
import java.awt.Color;
import utilitats.AlgorismesHash;
import java.util.*;

public abstract class FiguraGeometrica05 implements Comparable<Object> {
   protected int codi=0;
   protected String nom="";
   protected Color color=Color.white;

   public FiguraGeometrica05 (int ncodi, String nnom, Color ncolor) {
      if (ncodi>0) codi = ncodi;
      nom = nnom;
      color = ncolor;
   }

   public FiguraGeometrica05(FiguraGeometrica05 f) {
      this (f.codi, f.nom, f.color);
   }

   public FiguraGeometrica05 () {}

   public void setCodi(int nouCodi) {
      if (nouCodi>=0) codi = nouCodi;
   }

   public void setNom (String nouNom) {
      nom = nouNom;
   }

   public void setColor (Color nouColor) {
      color = nouColor;
   }   

   public int getCodi () {
      return codi;
   }

   public String getNom () {
      return nom;
   }
   
   public Color getColor () {
      return color;
   }

   public void visualitzar () {
      System.out.println ("Codi..........:" + codi);
      System.out.println ("Nom...........:" + nom);
      System.out.println ("Color.........:" + color);
   }

   public boolean equals (Object obj) {
      if (this == obj) return true;
      if (obj == null) return false;
      if (obj instanceof FiguraGeometrica05) return codi == ((FiguraGeometrica05)obj).codi;
      return false;
   }
   
   public String toString () {
      return codi + " - " + nom;
   }

   public abstract double area ();
   
   public int compareTo(Object obj) {
      if (obj instanceof Integer) return codi-((Integer)obj).intValue();
      return codi-((FiguraGeometrica05)obj).codi;
   }
}