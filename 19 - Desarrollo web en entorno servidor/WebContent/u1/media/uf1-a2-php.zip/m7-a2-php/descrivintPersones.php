<?php
//
//$quantitat = "10";
//$quantitat = (int) $quantitat;
//$quantitat++;
////echo $quantitat;
//
//var_dump((bool) "");        // bool(false)
//var_dump((bool) 1);         // bool(true)
//var_dump((bool) -2);        // bool(true)
//var_dump((bool) "foo");     // bool(true)
//var_dump((bool) 2.3e5);     // bool(true)
//var_dump((bool) array(12)); // bool(true)
//var_dump((bool) array());   // bool(false)
//var_dump((bool) "false");   // bool(true)
//
//var_dump(intval("1"));       
//var_dump(intval(array(3,9,8,6,"w"))); 
//var_dump(intval(array())); 
//var_dump(intval("-2"));      
//var_dump(intval(false));   
//var_dump(intval(true));    
//var_dump(intval(2.3e5));   
//var_dump(intval(NULL));    
//var_dump(intval(""));  
//
//$arr = array("a","e","i","o","u");
//$ser_var = serialize($arr);
//echo($ser_var);
//
//$array_text = 'a:5:{i:0;s:1:"a";i:1;s:1:"e";i:2;s:1:"i";i:3;s:1:"o";i:4;s:1:"u";}';
//$array_original = unserialize($array_text);
//echo $array_original[1];

//function calculaEdat($data){
//    $avui = date_create('today');
//    $e =  date_diff($avui, $data)->y;
//    return $e;
//}
//
//$nomPersona = "Clara"; //tipus string
//$cognoms = "Oswin"; // tipus string
//$data_naixement = date_create("1986-03-11"); //tipus date
//$edat = calculaEdat($data_naixement);
//echo $edat;

//$nomPersona = "Clara"; //tipus string
//$cognoms = "Oswin"; // tipus string
//$edat = 30;  // tipus integer
//$sou = 30000; //tipus integer
//$data_naixement = strtotime("1986-03-11"); //tipus date
//$telefon = "935555555"; // tipus string
//$adrecaPostal = "Blackpool, England"; //tipus string
//$email = "oswin@dr.who"; //tipus string
//$treballa = false; // tipus boolean
//$alcada = 167.23; // tipus float
//$convStringData = date("jS F, Y", $data_naixement); //Converteix a string una data segons un format donat.
//echo "La persona es diu $nomPersona $cognoms té $edat anys i guanya $sou €." .
//" La seva data de naixement és $convStringData i viu a $adrecaPostal." .
//" El seu e-mail és $email i la seva alçada és de $alcada. Creieu que treballa? $treballa.";

//function calculaEdat($data){
//    $avui = date_create('today');
//    $e =  date_diff($avui, $data)->y;
//    return $e;
//}
//
//$nomPersona = "Clara"; //tipus string
//$cognoms = "Oswin"; // tipus string
//$data_naixement = date_create("1986-03-11"); //tipus date
//$edat = calculaEdat($data_naixement);
//echo $edat."\n";
//
//if($edat < 30){
//   $sou = 10000;
//}
//else {
//   $sou = 20000;
//}
//echo $sou;

//
//$nomPersona = "Clara"; //tipus string
//$cognoms = "Oswin"; // tipus string
//$data_naixement = date_create("1986-03-11"); //tipus date
//
//function calculaEdat(){
//    $avui = date_create('today');
//    $e =  date_diff($avui, $data_naixement)->y;
//    return $e;
//}
//
//$edat = calculaEdat();
//echo $edat;

//function calculaEdat(){
//    $avui = date_create('today');
//    $diferencia =  date_diff($avui, $GLOBALS["data_naixement"] )->y;
//    return $diferencia;
//}
//
//$nomPersona = "Clara"; //tipus string
//$cognoms = "Oswin"; // tipus string
//$data_naixement = date_create("1986-03-11"); //tipus date
//$edat = calculaEdat();
//echo $edat;

function suma(){
   static $num;
   $num++;
   return $num."\n";
}
echo suma();
echo suma();
echo suma();