<?php
//Només una taula en el restaurant:
$comensals = rand(0,5);
echo "A la taula hi ha $comensals comensals <br>\n";

//Només una taula en el restaurant amb una millora: La taula està buida:
$comensals = rand(0,5);
if ($comensals == 0){
    echo "La taula està buida <br>\n";
}
else{
    echo "A la taula hi ha $comensals comensals <br>\n";
}

//Només una taula en el restaurant amb dos millores: taula buida i plena
$comensals = rand(0,5);
if ($comensals == 0){
    echo "La taula està buida <br>\n";
}
elseif ($comensals == 5){
    echo "La taula està plena <br>\n";
}
else {
    echo "A la taula hi ha $comensals comensals <br>\n";    
}


$taules = array();
$taules[0] = rand(0,5);
$taules[1] = rand(0,5);
$taules[2] = rand(0,5);
$taules[3] = rand(0,5);
$taules[4] = rand(0,5);
$taules[5] = rand(0,5);
$taules[6] = rand(0,5);
$taules[7] = rand(0,5);
$taules[8] = rand(0,5);
$taules[9] = rand(0,5);

//inicialització amb el número de comensals de les 10 taules
$taules = array();
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));
array_push($taules, rand(0,5));

//estructura de control FOR
$taules = array();
for($numTaula=0;$numTaula < 10 ; $numTaula++ ){
    $taules[$numTaula] = rand(0,5);
}
echo $taules[4];

//Estructura foreach
//
//creació de l'array
$taules = array();

//Omplir l'array aassociatiu:
for($numTaula=0;$numTaula < 10 ; $numTaula++ ){
    $taules["taula ".$numTaula] = rand(0,5);
}

//visualització del contingut de l'array
foreach($taules as $posicio => $comensals){
     echo "La $posicio té $comensals comensals\n<br>";
} 


$taules = array();

//Omplir l'array aassociatiu:
for($numTaula=0;$numTaula < 10 ; $numTaula++ ){
    $taules["taula ".$numTaula] = rand(0,5);
}

//visualització del contingut de l'array
foreach($taules as $posicio => $comensals){
   if ($comensals == 0){
       echo "La $posicio està buida\n<br>";
   }
   elseif ($comensals == 5){
       echo "La $posicio està plena\n<br>";
   }
   else {
       echo "A la $posicio hi ha $comensals comensals\n<br>";    
   }
} 

//Creació d'un array multidimensional
define("NUM_PLANTES", 5);
define("NUM_HAB", 10);
$habitacions = array();
for($pis=0; $pis < NUM_PLANTES; $pis++){
   $habitacions[$pis] = array();
   for($porta=0; $porta < NUM_HAB; $porta++){
       $habitacions[$pis][$porta] = "";
   }
}
print_r($habitacions);

////Creació d'un array multidimensional amb max 4 clients per habitacio
define("NUM_PLANTES", 5);
define("NUM_HAB", 10);
define("MAX_CLIENTS", 4);
$habitacions = array();
for($pis=0; $pis < NUM_PLANTES; $pis++){
   $habitacions[$pis] = array();
   for($porta=0; $porta < NUM_HAB; $porta++){
       $habitacions[$pis][$porta] = rand(0,MAX_CLIENTS);
   }
}
print_r($habitacions);

//LListat del nombre de persones per habitacio

//Crear l'estructura inicial
define("NUM_PLANTES", 5);
define("NUM_HAB", 10);
define("MAX_CLIENTS", 4);
$habitacions = array();
for($pis=0; $pis < NUM_PLANTES; $pis++){
   $habitacions[$pis] = array();
   for($porta=0; $porta < NUM_HAB; $porta++){
       $habitacions[$pis][$porta] = rand(0,MAX_CLIENTS);
   }
}

//recòrrer d'estructura per obtenir la informació:
for($pis=0; $pis < NUM_PLANTES; $pis++){
   for($porta=0; $porta < NUM_HAB; $porta++){
       
       switch ($habitacions[$pis][$porta]){
           case 0:
                echo "La habitació $porta de la planta $pis està buida.\n";
                break;
           case 4:
                echo "La habitació $porta de la planta $pis està plena.\n";
                break;
           default :
                echo "A la habitació $porta de la planta $pis hi ha ". $habitacions[$pis][$porta]. " persones.\n";
       }
       
   }
}


//Cercar si hi ha habitacions lliures
//Crear l'estructura inicial
define("NUM_PLANTES", 5);
define("NUM_HAB", 10);
define("MAX_CLIENTS", 4);
$habitacions = array();
for($pis=0; $pis < NUM_PLANTES; $pis++){
   $habitacions[$pis] = array();
   for($porta=0; $porta < NUM_HAB; $porta++){
       $habitacions[$pis][$porta] = rand(0,MAX_CLIENTS);
   } 
}

//recórrer l'estructura per obtenir la informació:
$pis=0;
$porta=0;
$trobat = false;
while (!$trobat && $pis < NUM_PLANTES){
    if($habitacions[$pis][$porta] == 0){
        $trobat = true;
    }
    if($porta == NUM_HAB -1){
        $porta = 0;
        $pis++;
    }
    else{
        $porta++;
    }
        
}

echo ($trobat)? "Al menys hi ha una habitació lliure." : "No existeixen habitacions lliures.";


