<?php
require_once('Calendari.php');
require_once('Store.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //creem el calendari. Si l'usuari ha clicat en alguna
        //data especial, s'agafa, sino, el calendari utilitzarà
        //la data actual
        $c = new Calendari($_REQUEST["data"]);
        $data = $c->getData();
        
        //Mirem si l'usuari ha afegit una cita a la data seleccionada
        if (isset($_REQUEST["cites"])) {
            //Agafem el contingut de la cita 
            $dadesAModificar = $_REQUEST["cites"];
            //La guardem a un fitxer en el servidor.
            Store::save($dadesAModificar, $data);
        }

        //Mirem les cites que hi ha a la data seleccionada
        $dadesAMostrar = Store::restore($data);

        ?>
        <!--Mostrem el calendari (la taula)-->
        <div><?php $c->view(); ?></div>
        <div>
            <!--Mostrem el formulari amb un text area on podem
                modificar les cites del dia seleccionat-->
            Amb la data seleccionada al calendari tens les següents cites:<br>
            <!--El text area està lligat al formulari però 
            no ha d'estar dintre de les etiquetes per a que 
            funcioni correctament-->
            <textarea form ="citesform" name="cites" id="cites" cols="35" wrap="soft"><?php print $dadesAMostrar; ?></textarea>
            <form method="POST" action="agenda.php" id="citesform">
                <!--Al utilitzar el formulari per enviar les dades
                hem de saber el dia seleccionat. Enviem també el dia
                amb un text ocult-->
                <input type="hidden" name="data" value="<?php echo $data ?>">
                <input type="submit" />
            </form> 
        </div>
    </body>
</html>
