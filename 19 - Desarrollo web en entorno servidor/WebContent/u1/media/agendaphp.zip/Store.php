<?php

class Store {

    private static $path = "./database/";

    public static function save($obj, $id) {
        if (!file_exists(self::$path)) {
            mkdir(self::$path);
        }   
        
        $arr = serialize($obj);
        
        return file_put_contents(self::$path . $id, $arr);
    }

    public static function restore($id) {
        
        if  (file_exists ( self::$path . $id ) ){
            
            $data = file_get_contents(self::$path . $id);
            
            return unserialize($data);  
            
        }
        
        return "";
    }
    
    public static function showNames(){
        
        return array_slice(scandir(self::$path),2);
        
    }
    
    public static function delete($id){
        
        return unlink(self::$path . $id);
        
    }   
    
}