<?php

class Calendari {

    private $data, $diainicial, $mes, $any, $diaMesos, $mesos, $dmaAnt, $dmaSeg, $diaSet;

    public function __construct($data) {
        date_default_timezone_set('Europe/Madrid');
        //data és la data en format aaaa-mm-dd
        //Comprovacions que la data és correcte. Si no és correcte agafa la data actual
        if (!ctype_digit(substr($data, 5, 2)) || !ctype_digit(substr($data, 8, 2)) || !ctype_digit(substr($data, 0, 4))) {
            $data = date('Y-m-d');
        } elseif (!checkdate((int) substr($data, 5, 2), (int) substr($data, 8, 2), (int) substr($data, 0, 4))) {
            $data = date('Y-m-d');
        }
        //data demanada
        $this->data = $data;
        //dia de la data
        $this->diainicial = substr($data, 8, 2);
        //mes de la data
        $this->mes = substr($data, 5, 2);
        //any de la data
        $this->any = substr($data, 0, 4);
        //mirem si l'any és de traspàs
        $esAnyDeTraspas = (($this->any % 400 == 0) || (($this->any % 100 != 0) && ($this->any % 4 == 0))) ? '1' : '0';
        
        //Calculem els dies de cada mes tenint en compte si es de traspas
        $this->diaMesos = ($esAnyDeTraspas) ?
                array(0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 31) :
                array(0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 31);
        
        //Array amb el nom dels mesos
        $this->mesos = array("", 'Gener', 'Febrer', 'Març', 'Abril', 'Maig',
            'Juny', 'Juliol', 'Agost', 'Setembre', 'Octubre',
            'Novembre', 'Desembre');

        //Calculem any següent i any anterior pels enllaços del calendari
        $this->dmaAnt = $this->calculData("anterior");
        $this->dmaSeg = $this->calculData("seguent");
        //Obtenim el dia de la setmana que comença el dia 1 
        //dilluns, dimarts... o diumenge?
        $jd = gregoriantojd($this->mes, 1, $this->any);
        $this->diaSet = (jddayofweek($jd, 0) + 6) % 7;
    }

    private function calculData($moment) {
        //Funció que calcula la mateixa data però del any anterior o de l'any següent
        $sig = ($moment === "anterior") ? 0 : 2;
        if ($this->diainicial > $this->diaMesos [(int) ($this->mes ) - 1 + $sig]) {
            return date('Y-m-d', mktime(0, 0, 0, $this->mes - 1 + $sig, $this->diaMesos[(int) ($this->mes) - 1 + $sig], $this->any));
        } else {
            return date('Y-m-d', mktime(0, 0, 0, $this->mes - 1 + $sig, $this->diainicial, $this->any));
        }
    }

    public function view() {
        //Funció que mostra el calendari en forma de taula
        //
        //Construim la taula per veure el calendari
        //tots els enllaços faran referència a la pàgina 
        //que utilitza el calendari
        $page = $_SERVER['PHP_SELF'];
        //Afegir els links pel mes anterior i el mes següent
        print "<div class=\"calendari\">\n  <table border=\"1\" class=\"calendario\" >\n";
        print "<caption><a href=\"$page?data=$this->dmaAnt\">&lt;&lt;</a> "
                . $this->mesos[(int) ($this->mes)] . " de $this->any <a href=\"$page?data="
                . "$this->dmaSeg\">&gt;&gt;</a></caption>\n";
        print "<tr>\n<th>DL</th>\n<th>DM</th>\n<th>DX</th><th>DJ</th>\n<th>DV</th>\n<th>DS</th>\n<th>DM</th>\n</tr>\n";

        //Mostrem una taula amb el calendari.
        //De 0 a 5 per que pot haber fins a 6 setmanes en un mes
        for ($setmana = 0; $setmana <= 5; $setmana++) {

            $num_inici = 1 - $this->diaSet + $setmana * 7;
            if ($num_inici <= $this->diaMesos[(int) ($this->mes)]) {

                print "<tr>\n";
                //Mostrem el 7 dies de la setmana segons sigui dilluns..
                $this->printSetmana($num_inici, $page);
                print "</tr>\n";
            }
        } print "  </table>\n</div>\n\n";
    }

    private function printSetmana($num_inici, $page) {
        //Mostrem cada dia del mes d'aquella setmana on toca.
        for ($i = 0; $i < 7; $i++) {
            $num = $num_inici + $i;
            if ($num > 0 && $num <= $this->diaMesos[(int) ($this->mes)]) {
                if ($num == $this->diainicial) {
                    //El dia actual no cal mnostrar el link
                    print "<td><b>$num</b></td>\n";
                } else {
                    //construïm el link per obtenir informació sobre aquesta data.
                    print "<td><a href=\"$page"
                            . "?data=$this->any-$this->mes-" . sprintf("%02d", $num)
                            . "\">$num</a></td>\n";
                }
            } else {
                //Si aquell dia de la setmana no li correspon cap 
                //dia numéric del més. Per exemple si el dia 1 cau en 
                //dimarts, el dilluns ha d'estar buit.
                print "<td> </td>\n";
            }
        }
    }

    public function getData() {
        return $this->data;
    }

}
