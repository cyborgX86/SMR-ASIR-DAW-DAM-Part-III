package cat.ioc.m7.activitatsservlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class CapcaleraResponse extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

                
	URL obj = new URL("http://ioc.xtec.cat");
	URLConnection conn = obj.openConnection();
	Map<String, List<String>> map = conn.getHeaderFields();
        
        response.setContentType("text/html");
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Capçalera de la resposta</title>");            
        out.println("</head>");
        out.println("<body>");

	out.println("<h1>Capçalera de la resposta...\n</h1>");
        
        out.println("<h3>Capçalera de la resposta del servidor ioc.xtec.cat al accedir al web: \n</h3>");
        
        out.println("<table width=\"100%\" border=\"1\" align=\"center\">\n");
        out.println("<tr bgcolor=\"#1acff6\">\n");
        out.println("<th>Nom del paràmetre de la capçalera</th><th>Valor(s)</th>\n");
        out.println("</tr>\n");
        
        
	for (Map.Entry<String, List<String>> entry : map.entrySet()) {
            String paramName = (String) entry.getKey();
            out.print("<tr><td>" + paramName + "</td>\n");         
            out.println("<td> " + entry.getValue() + "</td></tr>\n");

	}
        
	String server = conn.getHeaderField("Server");
        out.print("<tr><td>Server</td>\n");
	
        if (server == null) {
                out.print("<td>esconegut</td>\n");
	} else {
            	 out.print("<td>" + server + "</td>\n");

	}
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
 }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
