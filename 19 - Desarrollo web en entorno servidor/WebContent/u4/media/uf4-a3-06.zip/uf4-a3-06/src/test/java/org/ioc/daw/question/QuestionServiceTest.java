package org.ioc.daw.question;

import org.ioc.daw.answer.Answer;
import org.ioc.daw.config.SpringTestConfig;
import org.ioc.daw.user.User;
import org.ioc.daw.user.UserDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SpringTestConfig.class})
public class QuestionServiceTest {
    @Autowired
    private UserDAO userDAOMock;

    @Autowired
    private QuestionDAO questionDAOMock;

    @Autowired
    private QuestionService questionService;

    @Test
    public void getAllQUestions() {
        Question question1 = getDummyQuestion(1);
        Set<Question> questions = new HashSet<>();
        questions.add(question1);

        int userId = 1;
        User userMock = Mockito.mock(User.class);
        when(userMock.getQuestions()).thenReturn(questions);

        when(userDAOMock.getById(userId)).thenReturn(userMock);

        Set<Question> questionsResponse = questionService.getAllQuestions(userId);
        assertEquals(1, questionsResponse.size());
    }

    @Test
    public void addTheFirstAnswerToAQuestion() {
        int userID = 1;
        int questionId = 1;
        int answerId = 1;
        Answer answer = getDummyAnswer(answerId);
        Question question1 = getDummyQuestion(questionId);
        User user1 = getDummyUser(userID);

        when(userDAOMock.getById(userID)).thenReturn(user1);
        when(questionDAOMock.getById(questionId)).thenReturn(question1);
        when(questionDAOMock.update(question1)).thenReturn(question1);

        Question questionResponse = questionService.addAnswer(answer, questionId, userID);
        assertEquals(1, questionResponse.getAnswers().size());
        verify(userDAOMock, Mockito.times(1)).create(user1);
    }


    @Test
    public void addTheAnswerToAQuestionOnceItHasSomeAnswers() {
        int questionId = 1;
        int userID = 1;

        Answer answer1 = getDummyAnswer(1);
        Answer answer2 = getDummyAnswer(2);
        Question question1 = getDummyQuestion(questionId);
        Set<Answer> answers = new HashSet<>();
        answers.add(answer1);
        question1.setAnswers(answers);

        List<Question> questions = new ArrayList<>();
        questions.add(question1);

        User user1 = getDummyUser(userID);
        when(userDAOMock.getById(userID)).thenReturn(user1);
        when(questionDAOMock.getById(questionId)).thenReturn(question1);
        when(questionDAOMock.update(question1)).thenReturn(question1);

        questionService.addAnswer(answer2, questionId, userID);
        verify(userDAOMock, Mockito.times(1)).create(user1);
        assertEquals(2, answers.size());
    }

    @Test
    public void createFirstUserQuestion() {
        int userId = 1;
        Question question = getDummyQuestion(1);
        User user = getDummyUser(1);
        when(userDAOMock.getById(userId)).thenReturn(user);

        questionService.create(question, userId);

        verify(userDAOMock, timeout(1)).create(user);
        assertEquals(1, user.getQuestions().size());
    }


    @Test
    public void createUserQuestionWhenItsNotTheFirstOne() {
        int userId = 1;
        Question question1 = getDummyQuestion(1);
        Question question2 = getDummyQuestion(2);
        User user = getDummyUser(1);
        Set<Question> questions = new HashSet<>();
        questions.add(question1);
        user.setQuestions(questions);
        when(userDAOMock.getById(userId)).thenReturn(user);

        questionService.create(question2, userId);

        verify(userDAOMock, timeout(1)).create(user);
        assertEquals(2, questions.size());
    }

    private Question getDummyQuestion(int questionId) {
        Question question1 = new Question();
        question1.setQuestionId(questionId);
        question1.setText("Some question");
        Set<Question> questions = new HashSet<>();
        questions.add(question1);
        return question1;
    }

    private Answer getDummyAnswer(int answerId) {
        Answer answer = new Answer();
        answer.setAnswerId(answerId);
        answer.setText("This is an answer");
        return answer;
    }

    private User getDummyUser(int userId) {
        String username = "test";
        User user = new User();
        user.setUsername(username);
        user.setUserId(userId);
        return user;
    }
}