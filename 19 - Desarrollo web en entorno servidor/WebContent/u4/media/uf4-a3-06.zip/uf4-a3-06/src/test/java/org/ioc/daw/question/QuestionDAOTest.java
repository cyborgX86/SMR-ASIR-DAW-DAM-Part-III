package org.ioc.daw.question;

import org.ioc.daw.answer.Answer;
import org.ioc.daw.config.EmbeddedDatabaseTestConfig;
import org.ioc.daw.config.ServicesConfig;
import org.ioc.daw.user.User;
import org.ioc.daw.user.UserDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ServicesConfig.class, EmbeddedDatabaseTestConfig.class})
public class QuestionDAOTest {
    @Autowired
    private QuestionService questionService;

    @Autowired
    private UserDAO userDAO;

    @Test
    public void createQuestion() {
        User user = new User();
        user.setUsername("test");
        user.setActive(true);
        user.setEmail("email@test.com");
        user.setPassword("password");
        user.setName("name");
        user.setRank(10);
        user.setCreatedOn(new Timestamp(new Date().getTime()));
        userDAO.create(user);
        Question question = new Question();
        question.setText("This is a question");

        questionService.create(question, user.getUserId());
        assertNotNull(question.getQuestionId());

        Set<Question> questions = questionService.getAllQuestions(user.getUserId());
        assertEquals(1, questions.size());
    }

    @Test
    public void addAnswer() {
        User user = new User();
        user.setUsername("test");
        user.setActive(true);
        user.setEmail("email@test.com");
        user.setPassword("password");
        user.setName("name");
        user.setCreatedOn(new Timestamp(new Date().getTime()));
        userDAO.create(user);
        Question question = new Question();
        question.setText("This is a question");

        questionService.create(question, user.getUserId());

        Answer answer = new Answer();
        answer.setText("This is an answer");
        question = questionService.addAnswer(answer, question.getQuestionId(), user.getUserId());

        assertEquals(1, question.getAnswers().size());
    }
}