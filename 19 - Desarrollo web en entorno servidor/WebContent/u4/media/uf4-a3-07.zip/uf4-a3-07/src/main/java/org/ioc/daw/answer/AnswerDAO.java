package org.ioc.daw.answer;

public interface AnswerDAO {
    Answer getById(Integer questionId);
    void save(Answer question);
}
