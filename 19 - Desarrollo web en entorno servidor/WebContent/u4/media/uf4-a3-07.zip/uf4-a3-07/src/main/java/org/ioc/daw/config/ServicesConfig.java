package org.ioc.daw.config;

import org.ioc.daw.answer.AnswerDAO;
import org.ioc.daw.question.QuestionDAO;
import org.ioc.daw.question.QuestionService;
import org.ioc.daw.question.QuestionServiceImpl;
import org.ioc.daw.user.UserDAO;
import org.ioc.daw.user.UserService;
import org.ioc.daw.vote.VoteService;
import org.ioc.daw.vote.VoteServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServicesConfig {
    @Bean
    public QuestionService questionService(UserDAO userDAO, QuestionDAO questionDAO) {
        return new QuestionServiceImpl(userDAO, questionDAO);
    }

    @Bean
    public UserService userService(UserDAO userDAO) {
        return new UserService(userDAO);
    }

    @Bean
    public VoteService voteService(AnswerDAO answerDAO, UserDAO userDAO){
        return new VoteServiceImpl(answerDAO, userDAO);
    }
}
