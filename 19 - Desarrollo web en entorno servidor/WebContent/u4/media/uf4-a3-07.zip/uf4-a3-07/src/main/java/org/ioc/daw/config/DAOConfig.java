package org.ioc.daw.config;


import org.ioc.daw.answer.AnswerDAO;
import org.ioc.daw.answer.AnswerHibernateDAO;
import org.ioc.daw.question.QuestionDAO;
import org.ioc.daw.question.QuestionHibernateDAO;
import org.ioc.daw.user.UserDAO;
import org.ioc.daw.user.UserHibernateDAO;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DAOConfig {
    @Bean
    public AnswerDAO answerDAO(){
        return new AnswerHibernateDAO();
    }
    @Bean
    public UserDAO userDAO() {
        return new UserHibernateDAO();
    }

    @Bean
    public QuestionDAO questionDAO(){
        return new QuestionHibernateDAO();
    }
}
