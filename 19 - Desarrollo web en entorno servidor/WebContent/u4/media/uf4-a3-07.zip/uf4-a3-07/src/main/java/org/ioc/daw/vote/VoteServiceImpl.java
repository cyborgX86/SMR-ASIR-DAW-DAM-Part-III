package org.ioc.daw.vote;

import org.ioc.daw.answer.Answer;
import org.ioc.daw.answer.AnswerDAO;
import org.ioc.daw.user.User;
import org.ioc.daw.user.UserDAO;

import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.Set;

@Transactional
public class VoteServiceImpl implements VoteService {
    private AnswerDAO answerDAO;
    private UserDAO userDAO;

    public VoteServiceImpl(AnswerDAO answerDAO, UserDAO userDAO) {
        this.answerDAO = answerDAO;
        this.userDAO = userDAO;
    }

    @Override
    public void votePositive(Integer answerId, Integer userId) {
        vote(answerId, userId, true);
    }

    @Override
    public void voteNegative(Integer answerId, Integer userId) {
        vote(answerId, userId, false);
    }

    private Vote vote(Integer userId, Integer answerId, Boolean value) {
        User user = userDAO.getById(userId);
        Set<Vote> userVotes = user.getVotes();
        Vote vote = new Vote();
        vote.setVote(value);
        userVotes = getVotes(vote, userVotes);
        user.setVotes(userVotes);
        userDAO.create(user);

        Answer answer = answerDAO.getById(answerId);
        Set<Vote> votes = answer.getVotes();
        votes = getVotes(vote, votes);
        answer.setVotes(votes);
        answerDAO.save(answer);
        return vote;
    }

    private Set<Vote> getVotes(Vote vote, Set<Vote> votes) {
        if (votes != null) {
            votes.add(vote);
        } else {
            votes = new HashSet<Vote>();
            votes.add(vote);

        }
        return votes;
    }
}