package org.ioc.daw.question;

import org.ioc.daw.answer.Answer;

import java.util.Set;

public interface QuestionService {
    public Set<Question> getAllQuestions(Integer userId);
    public Question addAnswer(Answer answer, Integer questionId, Integer userId);
    public void create(Question question, Integer userId);
}