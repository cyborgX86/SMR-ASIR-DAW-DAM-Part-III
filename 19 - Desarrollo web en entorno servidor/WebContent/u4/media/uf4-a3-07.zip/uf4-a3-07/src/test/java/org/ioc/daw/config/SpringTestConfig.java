package org.ioc.daw.config;


import org.ioc.daw.answer.AnswerDAO;
import org.ioc.daw.question.QuestionDAO;
import org.ioc.daw.user.UserDAO;
import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@Import(value = {ServicesConfig.class})
public class SpringTestConfig {
    @Bean
    public UserDAO userDAO() {
        return Mockito.mock(UserDAO.class);
    }

    @Bean
    public QuestionDAO questionDAO() {
        return Mockito.mock(QuestionDAO.class);
    }

    @Bean
    public AnswerDAO answerDAO() {
        return Mockito.mock(AnswerDAO.class);
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        return Mockito.mock(PlatformTransactionManager.class);
    }

}