package org.ioc.daw.vote;

import org.ioc.daw.answer.Answer;
import org.ioc.daw.answer.AnswerDAO;
import org.ioc.daw.config.EmbeddedDatabaseTestConfig;
import org.ioc.daw.config.ServicesConfig;
import org.ioc.daw.question.Question;
import org.ioc.daw.question.QuestionService;
import org.ioc.daw.user.User;
import org.ioc.daw.user.UserDAO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import java.sql.Timestamp;
import java.util.Date;
import static org.junit.Assert.assertEquals;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ServicesConfig.class, EmbeddedDatabaseTestConfig.class})
public class VoteDAOTest {
    @Autowired
    private QuestionService questionService;

    @Autowired
    private UserDAO userDAO;

    @Autowired
    private AnswerDAO answerDAO;

    @Autowired
    private VoteService voteService;


    @Test
    public void votePositive() {
        User user1 = getUser("test", "test@email.com");
        User user2 = getUser("test1", "test1@email.com");
        User user3 = getUser("test2", "test2@email.com");
        userDAO.create(user1);
        userDAO.create(user2);
        userDAO.create(user3);

        Question question = new Question();
        question.setText("This is a question");
        questionService.create(question, user1.getUserId());

        Answer answer = new Answer();
        answer.setText("This is an answer");
        question = questionService.addAnswer(answer, question.getQuestionId(), user2.getUserId());

        int answerId = question.getAnswers().iterator().next().getAnswerId();
        voteService.votePositive(user3.getUserId(), answerId);

        User userDB = userDAO.getById(user3.getUserId());
        Answer answerDB = answerDAO.getById(answerId);
        assertEquals(1, userDB.getVotes().size());
        assertEquals(1, answerDB.getVotes().size());
        assertEquals(userDB.getVotes().iterator().next().getVoteId(), answerDB.getVotes().iterator().next().getVoteId());

    }

    private User getUser(String username, String email) {
        User user = new User();
        user.setUsername(username);
        user.setActive(true);
        user.setEmail(email);
        user.setPassword("password");
        user.setName("name");
        user.setCreatedOn(new Timestamp(new Date().getTime()));
        return user;
    }
}