CREATE TABLE users(user_id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
                  username VARCHAR(10) NOT NULL,
                  name  VARCHAR(20) NOT NULL,
                  email VARCHAR(50) NOT NULL,
                  rank INT DEFAULT 0,
                  created TIMESTAMP AS CURRENT_TIMESTAMP NOT NULL);

INSERT INTO users(col1, col2, col3) VALUE ('user1', 'John Doe', 'some@email.com');