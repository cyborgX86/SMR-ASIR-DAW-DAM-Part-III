package org.ioc.daw.config;

import org.ioc.daw.question.QuestionService;
import org.ioc.daw.question.QuestionServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServicesConfig {
    @Bean
    public QuestionService questionService(){
        return new QuestionServiceImpl();
    }
}
