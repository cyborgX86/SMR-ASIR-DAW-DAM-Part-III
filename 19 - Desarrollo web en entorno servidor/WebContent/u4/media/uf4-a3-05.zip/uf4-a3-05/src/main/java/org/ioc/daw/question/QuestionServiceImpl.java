package org.ioc.daw.question;

import org.ioc.daw.answer.Answer;
import org.ioc.daw.user.User;
import org.ioc.daw.user.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import javax.transaction.Transactional;
import java.util.HashSet;
import java.util.Set;

@Transactional
public class QuestionServiceImpl implements QuestionService {
    @Autowired
    private UserDAO userDAO;

    @Autowired
    private QuestionDAO questionDAO;


    @Override
    public Set<Question> getAllQuestions(Integer userId) {
        User user = userDAO.getById(userId);
        return user.getQuestions();
    }

    @Override
    public Question addAnswer(Answer answer, Integer questionId, Integer userId) {
        User user = userDAO.getById(userId);
        Set<Answer> userAnswers = user.getAnswers();
        addAnswerToCollection(answer, userAnswers);
        user.setAnswers(userAnswers);
        userDAO.create(user);

        Question question = questionDAO.getById(questionId);
        Set<Answer> answers = question.getAnswers();
        answers = addAnswerToCollection(answer, answers);
        question.setAnswers(answers);
        return questionDAO.update(question);
    }

    private Set<Answer> addAnswerToCollection(Answer answer, Set<Answer> answers) {
        if (answers != null) {
            answers.add(answer);
        } else {
            answers = new HashSet<Answer>();
            answers.add(answer);
        }
        return answers;
    }

    @Override
    public void create(Question question, Integer userId) {
        User user = userDAO.getById(userId);
        Set<Question> questions = user.getQuestions();
        if (questions != null) {
            questions.add(question);
        } else {
            questions = new HashSet<>();
            questions.add(question);
            user.setQuestions(questions);
        }
        userDAO.create(user);
    }
}