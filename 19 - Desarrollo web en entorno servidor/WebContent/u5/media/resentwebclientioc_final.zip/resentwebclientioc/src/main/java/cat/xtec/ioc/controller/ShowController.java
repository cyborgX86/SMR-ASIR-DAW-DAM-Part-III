package cat.xtec.ioc.controller;

import cat.xtec.ioc.service.client.jaxws.TicketService;
import cat.xtec.ioc.service.client.jaxws.TicketServiceEndpoint;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ShowController {
    
    private final TicketService showsWebService=new TicketService();

    @RequestMapping(value = "/shows", method = RequestMethod.GET)
    public ModelAndView shows(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ModelAndView modelview = new ModelAndView("shows");
        modelview.getModelMap().addAttribute("shows", showsWebService.getTicketServiceEndpointImplPort().getAllShows());
        return modelview;
    }
    
    @RequestMapping("/makeReservation")
    public ModelAndView makeReservation(@RequestParam("id") String id, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        showsWebService.getTicketServiceEndpointImplPort().makeReservation(id);
        ModelAndView modelview = new ModelAndView("shows");
        modelview.getModelMap().addAttribute("shows", showsWebService.getTicketServiceEndpointImplPort().getAllShows());
        return modelview;
    }
    
    @RequestMapping("/cancelReservation")
    public ModelAndView cancelReservation(@RequestParam("id") String id, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        showsWebService.getTicketServiceEndpointImplPort().cancelReservation(id);
        ModelAndView modelview = new ModelAndView("shows");
        modelview.getModelMap().addAttribute("shows", showsWebService.getTicketServiceEndpointImplPort().getAllShows());
        return modelview;
    }
}
