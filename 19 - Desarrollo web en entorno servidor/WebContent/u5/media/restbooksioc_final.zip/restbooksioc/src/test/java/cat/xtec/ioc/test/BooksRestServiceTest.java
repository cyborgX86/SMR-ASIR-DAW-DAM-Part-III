package cat.xtec.ioc.test;

import cat.xtec.ioc.domain.Book;
import java.net.URI;
import java.util.List;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class BooksRestServiceTest {

    private static final URI uri = UriBuilder.fromUri("http://localhost/restbooksioc/rest/books").port(8080).build();
    private static final Client client = ClientBuilder.newClient();

    @Test
    public void shouldReturnAllBooks() {
        // Arrange         
        URI uri = UriBuilder.fromUri("http://localhost/restbooksioc/rest/books").port(8080).build();
        WebTarget target = client.target(uri);
        Invocation invocation = target.request(MediaType.APPLICATION_JSON).buildGet();
        Book first = new Book("9788425343537", "Ildefonso Falcones", "La catedral del mar");
        Book second = new Book("9788467009477", "Jose Maria Peridis Perez", "La luz y el misterio de las catedrales");
        
        // Act
        Response res = invocation.invoke();
        List<Book> returnedBooks = res.readEntity(new GenericType<List<Book>>() {});
        
        // Assert
        assertTrue(returnedBooks.contains(first));                
        assertTrue(returnedBooks.contains(second));
    }
    
    @Test
    public void nonExistentBookShouldReturn404() {
        // Arrange    
        URI uri = UriBuilder.fromUri("http://localhost/restbooksioc/rest/books").port(8080).build();
        WebTarget target = client.target(uri).path("unknownISBN");
        Invocation invocation = target.request(MediaType.APPLICATION_JSON).buildGet();
        
        // Act
        Response res = invocation.invoke();       
        
        // Assert
        assertEquals(Response.Status.NOT_FOUND.toString(), res.getStatusInfo().toString());
    }
    
    @Test
    public void attemptsToCreateNullBooksShouldReturn400() {
        // Arrange    
        URI uri = UriBuilder.fromUri("http://localhost/restbooksioc/rest/books").port(8080).build();
        WebTarget target = client.target(uri);
        Invocation invocation = target.request(MediaType.APPLICATION_JSON).buildPost(null);
        
        // Act
        Response res = invocation.invoke();               
        
        // Assert
        assertEquals(Response.Status.BAD_REQUEST.toString(), res.getStatusInfo().toString());
    }
    
    @Test
    public void createBookShouldReturnTheURLToGetTheBook() {
        // Arrange    
        Book book = new Book("9788423342518", "Clara Sanchez", "Lo que esconde tu nombre");
        URI uri = UriBuilder.fromUri("http://localhost/restbooksioc/rest/books").port(8080).build();
        WebTarget target = client.target(uri);
        Invocation invocation = target.request(MediaType.APPLICATION_JSON).buildPost(Entity.entity(book, MediaType.APPLICATION_JSON));
        
        // Act
        Response res = invocation.invoke();      
        URI returnedUri = res.readEntity(URI.class);
        
        // Assert
        URI expectedUri = UriBuilder.fromUri("http://localhost/restbooksioc/rest/books").port(8080).path("9788423342518").build();
        assertEquals(expectedUri, returnedUri);
    }
}
