package cat.xtec.ioc.service;

import cat.xtec.ioc.domain.Book;
import cat.xtec.ioc.domain.repository.BookRepository;
import cat.xtec.ioc.domain.repository.impl.InMemoryBookRepository;
import java.net.URI;
import java.util.List;
import javax.inject.Singleton;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@Path("/books")
@Singleton
public class BooksRestService {

    @Context  private UriInfo uriInfo;
    
    private BookRepository bookRepository = new InMemoryBookRepository();   

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> getAll() {
        return this.bookRepository.getAll();
    }

    @GET
    @Path("{isbn}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response find(@PathParam("isbn") String isbn) {
        Book book = this.bookRepository.get(isbn);
        if(book == null) {
            throw new NotFoundException();
        }
        return Response.ok(book).build();
    }
    
    @GET
    @Path("findByTitle/{title}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> findByTitle(@PathParam("title") String title) {
        return this.bookRepository.findByTitle(title);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response create(Book book) {
        if(book == null) {
            throw new BadRequestException();
        }
        this.bookRepository.add(book);
        
        URI bookUri = uriInfo.getAbsolutePathBuilder().path(book.getIsbn()).build(); 
        return Response.ok(bookUri).build();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void edit(Book book) {
        this.bookRepository.update(book);
    }

    @DELETE
    @Path("{isbn}")
    public void remove(@PathParam("isbn") String isbn) {
        this.bookRepository.delete(isbn);
    }
}
