/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.service.impl;

import cat.xtec.ioc.domain.Show;
import cat.xtec.ioc.domain.repository.ShowRepository;
import cat.xtec.ioc.domain.repository.impl.InMemoryShowRepository;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author josepmaria.camps
 */
@WebService(serviceName = "NetbeansTicketService")
public class NetbeansTicketService {

    private final ShowRepository showRepository = new InMemoryShowRepository();
    /**
     * Web service operation
     */
    @WebMethod(operationName = "getAllShows")
    public ArrayList<Show> getAllShows() {
        return new ArrayList<Show>(this.showRepository.getAllShows());
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "makeReservation")
    public Show makeReservation(@WebParam(name = "showId") String showId) {
        return this.showRepository.makeReservation(showId);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "cancelReservation")
    public Show cancelReservation(@WebParam(name = "showId") String showId) {
        return this.showRepository.cancelReservation(showId);
    }
}
