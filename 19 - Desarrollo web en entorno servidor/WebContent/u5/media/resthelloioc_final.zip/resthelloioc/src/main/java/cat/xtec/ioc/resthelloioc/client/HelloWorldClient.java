package cat.xtec.ioc.resthelloioc.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


public class HelloWorldClient {

    public static void main(String[] args) {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:8080/resthelloioc/rest/hello");
        Invocation invocation = target.request(MediaType.TEXT_HTML).buildGet();
        Response res = (Response) invocation.invoke();        
        System.out.println(res.readEntity(String.class));
        
        // Forma concisa
        //Response response = ClientBuilder.newClient().target("http://localhost:8080/resthelloioc/rest/hello").request(MediaType.TEXT_HTML).get();
        
    }
}
