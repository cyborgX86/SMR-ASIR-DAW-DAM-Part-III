package cat.xtec.ioc.service;

import cat.xtec.ioc.domain.Book;
import cat.xtec.ioc.domain.repository.BookRepository;
import cat.xtec.ioc.domain.repository.impl.InMemoryBookRepository;
import java.util.List;
import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/books")
@Singleton
public class BooksRestService {

    private BookRepository bookRepository = new InMemoryBookRepository();   

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> getAll() {
        return this.bookRepository.getAll();
    }

    @GET
    @Path("{isbn}")
    @Produces(MediaType.APPLICATION_JSON)
    public Book find(@PathParam("isbn") String isbn) {
        return this.bookRepository.get(isbn);
    }
    
    @GET
    @Path("findByTitle/{title}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Book> findByTitle(@PathParam("title") String title) {
        return this.bookRepository.findByTitle(title);
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void create(Book book) {
        this.bookRepository.add(book);
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void edit(Book book) {
        this.bookRepository.update(book);
    }

    @DELETE
    @Path("{isbn}")
    public void remove(@PathParam("isbn") String isbn) {
        this.bookRepository.delete(isbn);
    }
}
