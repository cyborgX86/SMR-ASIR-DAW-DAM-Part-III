package cat.xtec.ioc.client;

import cat.xtec.ioc.service.jaxws.NetbeansTicketService;
import cat.xtec.ioc.service.jaxws.NetbeansTicketService_Service;
import cat.xtec.ioc.service.jaxws.Show;
import java.util.List;

public class NetBeansTicketServiceClient {
    
    public static void main(String[] args) {
        NetbeansTicketService_Service service = new NetbeansTicketService_Service();
        NetbeansTicketService port = service.getNetbeansTicketServicePort();
        List<Show> list = port.getAllShows();
        printALlShows(list);
    }

    public static void printALlShows(List<Show> shows) {
        shows.stream().forEach((show) -> {
            System.out.println("Show [id=" + show.getId() + ", name=" + show.getName() + ", available tickets=" + show.getAvailableTickets() + "]");
        });
    }    
}
