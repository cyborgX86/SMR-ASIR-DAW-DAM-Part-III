package cat.xtec.ioc.service.impl;

import cat.xtec.ioc.domain.Show;
import cat.xtec.ioc.domain.repository.ShowRepository;
import cat.xtec.ioc.domain.repository.impl.InMemoryShowRepository;
import javax.jws.WebService;
import cat.xtec.ioc.service.TicketServiceEndpoint;
import java.util.ArrayList;


@WebService(serviceName = "TicketService",
        endpointInterface = "cat.xtec.ioc.service.TicketServiceEndpoint")
public class TicketServiceEndpointImpl implements TicketServiceEndpoint {
    
    private final ShowRepository showRepository = new InMemoryShowRepository();
    
    @Override
    public ArrayList<Show> getAllShows() {
        return new ArrayList<Show>(this.showRepository.getAllShows());
    }        
    
    @Override
    public Show makeReservation(String showId) {
        return this.showRepository.makeReservation(showId);
    }
    
    @Override
    public Show cancelReservation(String showId) {
        return this.showRepository.cancelReservation(showId);
    }
}
