package cat.xtec.ioc.resthelloasyncioc.service;

import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("rest")
public class ApplicationConfig extends Application {

}
