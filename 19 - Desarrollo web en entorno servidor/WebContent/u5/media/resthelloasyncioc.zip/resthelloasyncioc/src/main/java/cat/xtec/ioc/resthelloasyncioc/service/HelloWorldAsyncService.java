package cat.xtec.ioc.resthelloasyncioc.service;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.ws.rs.core.Response;

@Stateless
@Path("/helloasync")
public class HelloWorldAsyncService {
    
    @Resource
    ManagedExecutorService mes;

    @GET
    @Produces("text/html")
    public void sayHelloAsync(@Suspended final AsyncResponse ar) {          
        final String initialThread = Thread.currentThread().getName();
        System.out.println("Thread: "+ initialThread + " in action...");
        
        mes.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        String processingThread = Thread.currentThread().getName();
                        System.out.println("Processing thread: " + processingThread);

                        Thread.sleep(5000);
                        String respBody = "Hello World!!! - Process initated in " + initialThread + " and finished in " + processingThread;
                        ar.resume(Response.ok(respBody).build());                    
                        
                    } catch (InterruptedException ex) {
                        Logger.getLogger(HelloWorldAsyncService.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });             
}
}
