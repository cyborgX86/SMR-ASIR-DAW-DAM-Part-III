package cat.xtec.ioc.resthelloasyncioc.client;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import javax.ws.rs.client.AsyncInvoker;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.InvocationCallback;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class HelloWorldAsyncClient {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:8080/resthelloasyncioc/rest/helloasync");
        Invocation.Builder reqBuilder = target.request();
        AsyncInvoker asyncInvoker = reqBuilder.async();
        Future<Response> futureResp = asyncInvoker.get(new InvocationCallback<Response>() {
            @Override
            public void completed(Response response) {
                String responseBody = response.readEntity(String.class);
                System.out.println(responseBody);
            }

            @Override
            public void failed(Throwable throwable) {
                System.out.println("Failed");                
            }

        });
        
        while (!futureResp.isDone()) {
            System.out.println("I'm not locked waiting for the service response ;-)");
        }        
    }
}
