package cat.xtec.ioc.domain.repository;

import cat.xtec.ioc.domain.Show;
import java.util.Collection;


public interface ShowRepository {
    Collection<Show> getAllShows();  
    Show makeReservation(String showId);
    Show cancelReservation(String showId);
}
