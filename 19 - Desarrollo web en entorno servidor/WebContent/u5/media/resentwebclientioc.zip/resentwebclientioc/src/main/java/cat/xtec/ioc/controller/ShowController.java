package cat.xtec.ioc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ShowController {
    
    
}
