package cat.xtec.ioc.client;

import cat.xtec.ioc.service.client.jaxws.Show;
import cat.xtec.ioc.service.client.jaxws.TicketService;
import cat.xtec.ioc.service.client.jaxws.TicketServiceEndpoint;
import java.util.List;

public class TicketServiceClient {

    public static void main(String[] args) {
        TicketService service = new TicketService();
        TicketServiceEndpoint port = service.getTicketServiceEndpointImplPort();
        List<Show> list = port.getAllShows();
        printALlShows(list);
    }

    public static void printALlShows(List<Show> shows) {
        shows.stream().forEach((show) -> {
            System.out.println("Show [id=" + show.getId() + ", name=" + show.getName() + ", available tickets=" + show.getAvailableTickets() + "]");
        });
    }
    
}