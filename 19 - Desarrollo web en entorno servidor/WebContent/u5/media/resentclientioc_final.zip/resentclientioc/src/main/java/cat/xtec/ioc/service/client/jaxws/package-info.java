@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.ioc.xtec.cat/")
package cat.xtec.ioc.service.client.jaxws;
