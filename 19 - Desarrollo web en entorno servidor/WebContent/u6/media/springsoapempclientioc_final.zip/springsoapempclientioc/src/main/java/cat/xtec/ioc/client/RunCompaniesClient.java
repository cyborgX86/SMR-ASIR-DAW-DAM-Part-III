package cat.xtec.ioc.client;

import cat.xtec.ioc.domain.companies.wsdl.GetCompanyResponse;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class RunCompaniesClient {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.register(ClientAppConfig.class);
        ctx.refresh();
        CompaniesClient companiesClient = ctx.getBean(CompaniesClient.class);
        System.out.println("For Company XXXXXXXX");
        GetCompanyResponse response = companiesClient.getCompanyInformation("XXXXXXXX");
        System.out.println("CIF: " + response.getCompany().getCif());
        System.out.println("Name: " + response.getCompany().getName());
        System.out.println("Num. employees: " + response.getCompany().getEmployees());
        System.out.println("Email: " + response.getCompany().getEmail());
        System.out.println("Web: " + response.getCompany().getWeb());
    }
}
