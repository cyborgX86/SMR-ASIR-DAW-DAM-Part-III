/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.xtec.ioc.client;

import cat.xtec.ioc.domain.companies.wsdl.GetCompanyRequest;
import cat.xtec.ioc.domain.companies.wsdl.GetCompanyResponse;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

public class CompaniesClient extends WebServiceGatewaySupport {

    public GetCompanyResponse getCompanyInformation(String cif) {
        GetCompanyRequest request = new GetCompanyRequest();
        request.setCif(cif);
        GetCompanyResponse response = (GetCompanyResponse) getWebServiceTemplate()
                .marshalSendAndReceive(request,
                        new SoapActionCallback("http://localhost:8080/soapws/getCompanyResponse"));

        return response;
    }

}
