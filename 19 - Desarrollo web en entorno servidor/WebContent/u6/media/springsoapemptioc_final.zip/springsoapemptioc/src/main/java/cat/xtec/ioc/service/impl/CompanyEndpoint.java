package cat.xtec.ioc.service.impl;


import cat.xtec.ioc.domain.repository.impl.InMemoryCompanyRepository;
import ioc.xtec.cat.domain.company.services.GetCompanyRequest;
import ioc.xtec.cat.domain.company.services.GetCompanyResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class CompanyEndpoint {
    private static final String NAMESPACE_URI = "http://cat.xtec.ioc/domain/company/services";

	private InMemoryCompanyRepository companyRepository;

	@Autowired
	public CompanyEndpoint(InMemoryCompanyRepository companyRepository) {
		this.companyRepository = companyRepository;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCompanyRequest")
	@ResponsePayload
	public GetCompanyResponse getCompany(@RequestPayload GetCompanyRequest request) {
		GetCompanyResponse response = new GetCompanyResponse();
		response.setCompany(companyRepository.findCompany(request.getCif()));

		return response;
	}
}
