package cat.xtec.ioc.domain.repository.impl;

import ioc.xtec.cat.domain.company.Company;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

@Repository
public class InMemoryCompanyRepository {

    private static final List<Company> companies = new ArrayList<Company>();

    @PostConstruct
    public void initData() {
        Company oracle = new Company();
        oracle.setCif("XXXXXXXX");
        oracle.setName("Oracle");
        oracle.setEmployees(5000);
        oracle.setEmail("oracle@oracle.com");
        oracle.setWeb("http://www.oracle.com");

        companies.add(oracle);

        Company ms = new Company();
        ms.setCif("YYYYYYYY");
        ms.setName("Microsoft");
        ms.setEmployees(10000);
        ms.setEmail("microsoft@microsoft.com");
        ms.setWeb("http://www.microsoft.com");

        companies.add(ms);

        Company redhat = new Company();
        redhat.setCif("ZZZZZZZZ");
        redhat.setName("Red Hat");
        redhat.setEmployees(2000);
        redhat.setEmail("redhat@redhat.com");
        redhat.setWeb("http://www.redhat.com");
        companies.add(redhat);
    }

    public Company findCompany(String cif) {
        Assert.notNull(cif);
        Company result = null;
        for (Company company : companies) {
            if (cif.equals(company.getCif())) {
                result = company;
            }
        }

        return result;
    }
}
