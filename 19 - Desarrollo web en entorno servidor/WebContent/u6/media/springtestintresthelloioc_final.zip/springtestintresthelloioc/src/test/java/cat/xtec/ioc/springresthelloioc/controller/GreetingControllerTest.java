
package cat.xtec.ioc.springresthelloioc.controller;

import javax.ws.rs.core.MediaType;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


public class GreetingControllerTest {
    private static final String uri = "http://localhost:8080/springtestintresthelloioc/hello";
    
    @Test
    public void greetingShouldReturnHelloWorldWithoutName() {
        // Arrange                 
        RestTemplate restTemplate = new RestTemplate();
        
        // Act
        GreetingTest greeting = restTemplate.getForObject(uri, GreetingTest.class);
        
        // Assert
        assertEquals("Hello, World!!!", greeting.getContent());         
    }
        
    
    @Test
    public void greetingShouldReturnOKAndJSON () {
        // Arrange                 
        RestTemplate restTemplate = new RestTemplate();
        
        // Act
        ResponseEntity<GreetingTest> response = restTemplate.getForEntity(uri, GreetingTest.class);
        
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());    
        assertEquals(MediaType.APPLICATION_JSON, response.getHeaders().getContentType().getType() + "/" + response.getHeaders().getContentType().getSubtype()); 
    }
    
    @Test
    public void greetingShouldReturnHelloNameWithName() {
        // Arrange                 
        RestTemplate restTemplate = new RestTemplate();
        
        // Act
        GreetingTest greeting = restTemplate.getForObject(uri + "?name=User", GreetingTest.class);
        
        // Assert
        assertEquals("Hello, User", greeting.getContent());         
    }
}
