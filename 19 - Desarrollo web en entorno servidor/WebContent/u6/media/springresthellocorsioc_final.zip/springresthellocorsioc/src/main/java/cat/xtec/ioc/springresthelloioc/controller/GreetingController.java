package cat.xtec.ioc.springresthelloioc.controller;

import cat.xtec.ioc.springresthelloioc.domain.Greeting;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

    private static final String template = "Hello, %s";
    private final AtomicLong counter = new AtomicLong();

    @CrossOrigin(origins = "http://localhost:8080")
    @RequestMapping(method =  RequestMethod.GET, value = "/hello")
    public Greeting greeting(@RequestParam(value="name", defaultValue="World!!!") String name) {
        return new Greeting(counter.incrementAndGet(),
                            String.format(template, name));
    }
}