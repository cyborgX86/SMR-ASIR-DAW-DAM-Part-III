package cat.xtec.ioc.controller;

import cat.xtec.ioc.domain.Team;
import cat.xtec.ioc.domain.repository.TeamRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

@RestController
public class TeamsController {

    @Autowired
    private TeamRepository teamRepository;

    public TeamsController() {
    }

    public TeamsController(TeamRepository teamRepository) {
        this.teamRepository = teamRepository;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/teams")
    public @ResponseBody
    List<Team> getAll() {
        return this.teamRepository.getAll();
    }

    @RequestMapping(value = "/teams/{id}", method = RequestMethod.GET)
    public @ResponseBody
    Team getById(@PathVariable int id) {
        Team team = this.teamRepository.get(id);
        final Link link = linkTo(methodOn(PlayerController.class).getTeamPlayers(team.getTeamId())).withRel("players");
        team.add(link);
        return team;
    }
}
