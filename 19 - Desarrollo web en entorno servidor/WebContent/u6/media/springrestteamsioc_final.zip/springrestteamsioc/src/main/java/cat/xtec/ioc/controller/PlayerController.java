package cat.xtec.ioc.controller;

import cat.xtec.ioc.domain.Player;
import cat.xtec.ioc.domain.repository.PlayerRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/teams/{teamId}/players")
public class PlayerController {

    @Autowired
    private PlayerRepository playerRepository;

    public PlayerController() {
    }

    public PlayerController(PlayerRepository playerRepository) {
        this.playerRepository = playerRepository;
    }

    @RequestMapping(method = RequestMethod.GET)
    public @ResponseBody
    List<Player> getTeamPlayers(@PathVariable int teamId) {
        return this.playerRepository.getByTeam(teamId);
    }

    @RequestMapping(value = "{playerId}", method = RequestMethod.GET)
    public @ResponseBody
    Player getById(@PathVariable int teamId, @PathVariable int playerId) {
        return this.playerRepository.get(teamId, playerId);
    }

    @RequestMapping(method = RequestMethod.POST)
    public @ResponseBody
    ResponseEntity<Player> create(@PathVariable int teamId, @RequestBody Player player) {
        player.setTeamId(teamId);
        this.playerRepository.add(player);
        return new ResponseEntity<>(player, HttpStatus.CREATED);
    }

    @RequestMapping(method = RequestMethod.PUT)
    public @ResponseBody
    ResponseEntity<Player> update(@PathVariable int teamId, @RequestBody Player player) {
        player.setTeamId(teamId);
        this.playerRepository.update(player);
        return new ResponseEntity<>(player, HttpStatus.OK);
    }

    @RequestMapping(value = "{playerId}", method = RequestMethod.DELETE)
    public @ResponseBody
    ResponseEntity<Player> delete(@PathVariable int teamId, @PathVariable int playerId) {
        this.playerRepository.delete(teamId, playerId);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
