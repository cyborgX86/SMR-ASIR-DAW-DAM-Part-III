package cat.xtec.ioc.domain;

import java.util.Objects;

public class Team {

    private int teamId;
    private String name;
    private String foundationYear;

    public Team(int id, String name, String foundationYear) {
        this.teamId = id;
        this.name = name;
        this.foundationYear = foundationYear;
    }

    public Team() {
    }

    public int getTeamId() {
        return teamId;
    }

    public void setTeamId(int teamId) {
        this.teamId = teamId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFoundationYear() {
        return foundationYear;
    }

    public void setFoundationYear(String foundationYear) {
        this.foundationYear = foundationYear;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Team)) {
            return false;
        }

        final Team other = (Team) o;
        return other.getTeamId() == this.teamId;

    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.name);
    }

    @Override
    public String toString() {
        return "Team{"
                + "id=" + teamId
                + ", name='" + name + '\''
                + ", foundationYear=" + foundationYear
                + '}';
    }

}
