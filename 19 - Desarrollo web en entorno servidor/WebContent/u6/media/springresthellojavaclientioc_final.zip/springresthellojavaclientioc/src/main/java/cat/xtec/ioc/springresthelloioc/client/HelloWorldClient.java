package cat.xtec.ioc.springresthelloioc.client;

import org.springframework.web.client.RestTemplate;

public class HelloWorldClient {

    public static void main(String[] args) {
        RestTemplate restTemplate = new RestTemplate();
        GreetingClient greeting = restTemplate.getForObject("http://localhost:8080/springresthellojavaclientioc/hello", GreetingClient.class);
        System.out.println(greeting.toString());
        greeting = restTemplate.getForObject("http://localhost:8080/springresthellojavaclientioc/hello?name=User", GreetingClient.class);
        System.out.println(greeting.toString());
    }

}
